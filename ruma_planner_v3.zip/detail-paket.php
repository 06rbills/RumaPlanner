<?php
require_once 'includes/config.php';
require_once 'includes/koneksi.php';
require_once 'includes/session.php';

$id = (int)($_GET['id'] ?? 0);
if (!$id) { header('Location: ' . BASE_URL . 'paket.php'); exit(); }

$stmt = $pdo->prepare("SELECT * FROM paket WHERE id=? AND is_active=1");
$stmt->execute([$id]);
$p = $stmt->fetch();
if (!$p) { header('Location: ' . BASE_URL . 'paket.php'); exit(); }

$fasilitas = explode('|', $p['fasilitas']);

// Map fasilitas keyword → kategori vendor slug
$fasilitasVendorMap = [
    'MUA'          => 'mua',
    'Make Up'      => 'mua',
    'Makeup'       => 'mua',
    'Foto'         => 'photographer',
    'Fotografer'   => 'photographer',
    'Dokumentasi'  => 'photographer',
    'Video'        => 'videografer',
    'Videografer'  => 'videografer',
    'Cinematic'    => 'videografer',
    'MC'           => 'mc',
    'Catering'     => 'catering',
    'Musik'        => 'musik',
    'Band'         => 'musik',
    'Live Music'   => 'musik',
    'Entertainer'  => 'musik',
    'Dekorasi'     => 'dekorasi',
    'Pelaminan'    => 'dekorasi',
    'Bunga'        => 'dekorasi',
    'Gedung'       => 'gedung',
    'Ballroom'     => 'gedung',
    'Venue'        => 'gedung',
];

// Untuk tiap fasilitas, cari slug kategori yang cocok
function getFasilitasSlug($fasilitasName, $map) {
    foreach ($map as $keyword => $slug) {
        if (stripos($fasilitasName, $keyword) !== false) return $slug;
    }
    return null;
}

// Ambil semua vendor dikelompokkan per kategori slug
$allVendors = $pdo->query("
    SELECT v.*, vk.nama AS nama_kategori, vk.slug AS kategori_slug, vk.icon AS kategori_icon
    FROM vendor v JOIN vendor_kategori vk ON v.id_kategori=vk.id
    WHERE v.is_active=1 ORDER BY v.rating DESC
")->fetchAll();

$vendorBySlug = [];
foreach ($allVendors as $vd) {
    $vendorBySlug[$vd['kategori_slug']][] = $vd;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($p['nama_paket']) ?> — <?= SITE_NAME ?></title>
    <link rel="shortcut icon" href="<?= BASE_URL ?>assets/images/icon.jpg">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
    <style>
    /* Fasilitas item clickable */
    .fasilitas-item {
        display:flex; align-items:flex-start; gap:10px;
        padding:14px 16px; border-radius:var(--radius);
        background:var(--maroon-pale);
        border:2px solid transparent;
        transition:var(--transition);
        position:relative;
        cursor:default;
    }
    .fasilitas-item.has-vendor {
        cursor:pointer;
        border-color:rgba(105,27,27,0.12);
    }
    .fasilitas-item.has-vendor:hover {
        background:#fde8e8;
        border-color:var(--maroon);
        transform:translateY(-1px);
        box-shadow:var(--shadow-sm);
    }
    .fasilitas-item.vendor-selected {
        border-color:var(--maroon);
        background:#fde8e8;
    }
    .fasilitas-item .vendor-hint {
        position:absolute; top:8px; right:10px;
        font-size:0.68rem; color:var(--maroon);
        font-weight:600; opacity:0.7;
        display:flex; align-items:center; gap:3px;
    }
    .fasilitas-item .selected-vendor-name {
        font-size:0.72rem; color:var(--maroon);
        font-weight:600; margin-top:3px;
        display:none;
    }
    .fasilitas-item.vendor-selected .selected-vendor-name { display:block; }

    /* Modal Vendor Picker */
    .vendor-picker-modal .modal-dialog { max-width:720px; }
    .vendor-picker-modal .modal-header {
        background:linear-gradient(135deg,var(--maroon-dark),var(--maroon));
        color:#fff; border:none;
    }
    .vendor-picker-modal .modal-title { font-family:var(--font-display); font-size:1.4rem; }
    .vendor-picker-modal .btn-close { filter:invert(1); }
    .vendor-pick-card {
        border:2px solid rgba(105,27,27,0.1);
        border-radius:var(--radius);
        padding:16px;
        cursor:pointer;
        transition:var(--transition);
        background:#fff;
        position:relative;
    }
    .vendor-pick-card:hover {
        border-color:var(--maroon);
        box-shadow:var(--shadow-sm);
        transform:translateY(-2px);
    }
    .vendor-pick-card.selected {
        border-color:var(--maroon);
        background:var(--maroon-pale);
    }
    .vendor-pick-card .selected-check {
        position:absolute; top:10px; right:10px;
        width:24px; height:24px; border-radius:50%;
        background:var(--maroon); color:#fff;
        display:none; align-items:center; justify-content:center;
        font-size:0.8rem;
    }
    .vendor-pick-card.selected .selected-check { display:flex; }
    .vendor-pick-img {
        width:56px; height:56px; border-radius:10px; flex-shrink:0;
        background:linear-gradient(135deg,var(--maroon-dark),var(--maroon));
        display:flex; align-items:center; justify-content:center;
    }
    .vendor-pick-img i { font-size:1.4rem; color:rgba(255,255,255,0.6); }
    .vendor-pick-badge { font-size:0.65rem; padding:2px 8px; border-radius:50px; font-weight:700; }
    .badge-gold-sm { background:var(--gold); color:#fff; }

    /* Price summary bar */
    .price-bar {
        position:sticky; bottom:0; z-index:10;
        background:#fff; border-top:2px solid var(--maroon-pale);
        padding:16px 0;
        box-shadow:0 -8px 24px rgba(105,27,27,0.08);
    }
    </style>
</head>
<body>
<?php include 'includes/navbar.php'; ?>

<div class="page-header" style="padding-top:100px;">
    <div class="container">
        <nav aria-label="breadcrumb" class="mb-3">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?= BASE_URL ?>index.php">Beranda</a></li>
                <li class="breadcrumb-item"><a href="<?= BASE_URL ?>paket.php">Paket</a></li>
                <li class="breadcrumb-item active"><?= htmlspecialchars($p['nama_paket']) ?></li>
            </ol>
        </nav>
        <h1><?= htmlspecialchars($p['nama_paket']) ?></h1>
    </div>
</div>

<section class="section-padding">
    <div class="container">
        <div class="row g-5">
            <!-- Image & Booking Panel -->
            <div class="col-lg-5">
                <div class="paket-card-img rounded-xl" style="height:340px;">
                    <?php if ($p['foto'] && file_exists(UPLOAD_PAKET . $p['foto'])): ?>
                        <img src="<?= UPLOAD_URL_PAKET . htmlspecialchars($p['foto']) ?>" alt="<?= htmlspecialchars($p['nama_paket']) ?>" style="border-radius:var(--radius-lg);">
                    <?php else: ?>
                        <div class="paket-card-img-placeholder" style="border-radius:var(--radius-lg);">
                            <i class="bi bi-house-heart" style="font-size:5rem;color:rgba(255,255,255,0.4);display:block;"></i>
                        </div>
                    <?php endif; ?>
                    <span class="badge-kategori"><?= htmlspecialchars($p['kategori']) ?></span>
                </div>

                <!-- Booking Card -->
                <div class="form-card mt-4">
                    <div class="paket-harga mb-1" id="displayHarga"><?= formatRupiah($p['harga']) ?></div>
                    <p class="text-muted mb-0" style="font-size:0.82rem;">Harga dasar paket</p>
                    <div id="vendorAddons" style="display:none;" class="mt-2">
                        <div style="font-size:0.78rem;color:#888;">+ Biaya vendor pilihan</div>
                        <div id="addonList" style="font-size:0.83rem;color:var(--maroon);"></div>
                        <hr style="margin:8px 0;">
                        <div class="d-flex justify-content-between align-items-center">
                            <strong style="font-size:0.85rem;">Total Estimasi</strong>
                            <strong id="totalHarga" style="font-family:var(--font-display);font-size:1.2rem;color:var(--maroon);"></strong>
                        </div>
                    </div>
                    <hr>
                    <div class="row text-center g-3 mb-3">
                        <div class="col-6">
                            <i class="bi bi-people-fill" style="font-size:1.4rem;color:var(--maroon);"></i>
                            <div style="font-size:1.2rem;font-weight:700;color:var(--maroon);"><?= $p['max_tamu'] ?></div>
                            <div style="font-size:0.78rem;color:#888;">Maks. Tamu</div>
                        </div>
                        <div class="col-6">
                            <i class="bi bi-star-fill" style="font-size:1.4rem;color:var(--gold);"></i>
                            <div style="font-size:1.2rem;font-weight:700;color:var(--maroon);"><?= count($fasilitas) ?></div>
                            <div style="font-size:0.78rem;color:#888;">Fasilitas</div>
                        </div>
                    </div>
                    <div class="d-grid gap-2">
                        <a href="<?= isLoggedIn() ? BASE_URL . 'client/form-booking.php?paket=' . $p['id'] : BASE_URL . 'login.php' ?>"
                           class="btn btn-maroon" id="btnPesan">
                            <i class="bi bi-heart me-2"></i>Pesan Paket Ini
                        </a>
                        <a href="kontak.php" class="btn btn-outline-maroon">
                            <i class="bi bi-chat me-2"></i>Tanya Dahulu
                        </a>
                    </div>
                    <?php if (!isLoggedIn()): ?>
                    <p class="text-center mt-2" style="font-size:0.8rem;color:#888;">
                        <i class="bi bi-info-circle me-1"></i>Perlu <a href="login.php" style="color:var(--maroon);">login</a> untuk memesan
                    </p>
                    <?php endif; ?>
                </div>

                <!-- DP Info -->
                <div class="mt-3 p-4 rounded-xl" style="background:linear-gradient(135deg,var(--maroon),var(--maroon-light));color:white;">
                    <h6 style="font-family:var(--font-display);font-size:1.1rem;margin-bottom:12px;">
                        <i class="bi bi-credit-card me-2 text-gold"></i>Informasi Pembayaran
                    </h6>
                    <div class="row">
                        <div class="col-6">
                            <div style="font-size:0.78rem;opacity:0.8;">Down Payment (30%)</div>
                            <div style="font-size:1.1rem;font-weight:700;color:var(--gold);"><?= formatRupiah($p['harga'] * 0.3) ?></div>
                        </div>
                        <div class="col-6">
                            <div style="font-size:0.78rem;opacity:0.8;">Pelunasan (70%)</div>
                            <div style="font-size:1.1rem;font-weight:700;color:var(--gold);"><?= formatRupiah($p['harga'] * 0.7) ?></div>
                        </div>
                    </div>
                    <p style="font-size:0.8rem;opacity:0.75;margin-top:12px;margin-bottom:0;">* DP dibayarkan saat booking. Pelunasan H-7 acara.</p>
                </div>
            </div>

            <!-- Detail & Fasilitas -->
            <div class="col-lg-7">
                <span class="section-subtitle" style="display:block;"><?= htmlspecialchars($p['kategori']) ?> Package</span>
                <h2 style="font-family:var(--font-display);font-size:2.5rem;color:var(--maroon);">
                    <?= htmlspecialchars($p['nama_paket']) ?>
                </h2>
                <div class="divider-gold" style="margin:16px 0 24px;"></div>
                <p style="color:#555;line-height:1.9;font-size:0.95rem;margin-bottom:32px;">
                    <?= nl2br(htmlspecialchars($p['deskripsi'])) ?>
                </p>

                <h5 style="font-family:var(--font-display);color:var(--maroon);font-size:1.3rem;margin-bottom:6px;">
                    <i class="bi bi-check2-circle me-2 text-gold"></i>Yang Anda Dapatkan
                </h5>
                <p style="font-size:0.82rem;color:#888;margin-bottom:16px;">
                    <i class="bi bi-hand-index me-1"></i>
                    Klik fasilitas yang ada tombol <span style="color:var(--maroon);font-weight:600;">Pilih Vendor</span> untuk memilih vendor spesifik
                </p>

                <div class="row g-2" id="fasilitasList">
                    <?php foreach ($fasilitas as $idx => $f): ?>
                    <?php
                        $f = trim($f);
                        $slug = getFasilitasSlug($f, $fasilitasVendorMap);
                        $hasVendor = $slug && !empty($vendorBySlug[$slug]);
                        $vendorSlugJson = $slug ? htmlspecialchars($slug) : '';
                        $fasilitasLabel = htmlspecialchars($f);
                    ?>
                    <div class="col-md-6">
                        <div class="fasilitas-item <?= $hasVendor ? 'has-vendor' : '' ?>"
                             <?= $hasVendor ? "onclick=\"openVendorPicker('$vendorSlugJson', '$fasilitasLabel', $idx)\"" : '' ?>
                             id="fasilitas-<?= $idx ?>"
                             data-fasilitas="<?= $fasilitasLabel ?>"
                             data-slug="<?= $vendorSlugJson ?>">
                            <i class="bi bi-check-circle-fill" style="color:var(--maroon);margin-top:2px;min-width:16px;"></i>
                            <div>
                                <span style="font-size:0.88rem;"><?= $fasilitasLabel ?></span>
                                <div class="selected-vendor-name" id="selected-name-<?= $idx ?>"></div>
                            </div>
                            <?php if ($hasVendor): ?>
                            <span class="vendor-hint"><i class="bi bi-people"></i> Pilih Vendor</span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>

                <!-- Vendor Selection Summary -->
                <div id="selectionSummary" class="mt-4 p-4 rounded-xl" style="background:var(--maroon-pale);border:2px solid rgba(105,27,27,0.15);display:none;">
                    <h6 style="font-family:var(--font-display);color:var(--maroon);margin-bottom:12px;">
                        <i class="bi bi-list-check me-2"></i>Vendor yang Dipilih
                    </h6>
                    <div id="summaryList"></div>
                    <div class="mt-3 d-flex gap-2">
                        <a href="<?= isLoggedIn() ? BASE_URL . 'client/form-booking.php?paket=' . $p['id'] : BASE_URL . 'login.php' ?>" 
                           class="btn btn-maroon btn-sm flex-grow-1">
                            <i class="bi bi-heart me-1"></i>Lanjut Booking dengan Vendor Ini
                        </a>
                        <button onclick="resetVendors()" class="btn btn-outline-maroon btn-sm">
                            <i class="bi bi-arrow-clockwise"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ===== VENDOR PICKER MODAL ===== -->
<div class="modal fade vendor-picker-modal" id="vendorPickerModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <div>
                    <div style="font-size:0.75rem;opacity:0.75;text-transform:uppercase;letter-spacing:1px;">Pilih Vendor untuk</div>
                    <div class="modal-title" id="modalFasilitasTitle">—</div>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-3" id="vendorPickerBody">
                <!-- Diisi JS -->
            </div>
            <div class="modal-footer" style="background:var(--off-white);">
                <button type="button" class="btn btn-outline-maroon btn-sm" data-bs-dismiss="modal">Batal</button>
                <button type="button" class="btn btn-maroon btn-sm" id="btnConfirmVendor" onclick="confirmVendor()">
                    <i class="bi bi-check-circle me-1"></i>Pilih Vendor Ini
                </button>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
<a href="https://wa.me/6281234567890?text=<?= urlencode('Halo, saya ingin bertanya mengenai paket wedding Ruma Planner.') ?>" target="_blank" class="wa-float" title="Chat Admin Ruma Planner"><i class="bi bi-whatsapp"></i></a>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= BASE_URL ?>assets/js/main.js"></script>
<script>
// ── DATA dari PHP ──────────────────────────────────────────
const vendorData = <?= json_encode($vendorBySlug, JSON_UNESCAPED_UNICODE) ?>;
const baseHarga  = <?= $p['harga'] ?>;

// ── STATE ──────────────────────────────────────────────────
let selectedVendors  = {};   // { fasilitasIdx: { id, nama, harga, slug } }
let currentFasilitas = null; // { slug, label, idx }
let tempSelected     = null; // vendor yang lagi di-hover/klik di modal

const modal = new bootstrap.Modal(document.getElementById('vendorPickerModal'));

// ── BUKA MODAL ─────────────────────────────────────────────
function openVendorPicker(slug, label, idx) {
    currentFasilitas = { slug, label, idx };
    tempSelected = selectedVendors[idx] || null;

    document.getElementById('modalFasilitasTitle').textContent = label;
    renderVendorCards(slug, idx);
    modal.show();
}

function renderVendorCards(slug, idx) {
    const vendors = vendorData[slug] || [];
    const body = document.getElementById('vendorPickerBody');

    if (vendors.length === 0) {
        body.innerHTML = '<div class="text-center py-4 text-muted"><i class="bi bi-emoji-frown" style="font-size:2.5rem;opacity:0.3;"></i><p class="mt-2">Belum ada vendor tersedia</p></div>';
        return;
    }

    let html = '<div class="row g-3">';
    vendors.forEach(v => {
        const isSelected = tempSelected && tempSelected.id === v.id;
        const hargaExtra = v.harga_mulai > 0 ? '<span style="color:var(--maroon);font-size:0.78rem;font-weight:600;">+' + formatRp(v.harga_mulai) + ' <small style=\'color:#999;font-weight:400;\'>' + v.harga_satuan + '</small></span>' : '<span style="color:#28a745;font-size:0.78rem;font-weight:600;">Sudah termasuk paket</span>';
        const badge = v.badge ? `<span class="vendor-pick-badge badge-gold-sm me-1">${v.badge}</span>` : '';
        html += `
        <div class="col-12">
          <div class="vendor-pick-card ${isSelected ? 'selected' : ''}" onclick="selectVendorCard(this, ${v.id}, '${escJs(v.nama)}', ${v.harga_mulai}, '${escJs(v.harga_satuan)}')">
            <div class="selected-check"><i class="bi bi-check"></i></div>
            <div class="d-flex gap-3 align-items-start">
              <div class="vendor-pick-img"><i class="bi ${escJs(v.kategori_icon)}"></i></div>
              <div class="flex-grow-1">
                <div class="d-flex align-items-center gap-2 flex-wrap mb-1">
                  <strong style="font-size:0.95rem;">${escHtml(v.nama)}</strong>
                  ${badge}
                </div>
                <div style="color:var(--gold);font-size:0.78rem;margin-bottom:4px;">${'★'.repeat(Math.round(v.rating))}${'☆'.repeat(5-Math.round(v.rating))} <span style="color:#888;">${v.rating} (${v.total_review} ulasan)</span></div>
                <p style="font-size:0.8rem;color:#666;margin-bottom:6px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;">${escHtml(v.deskripsi)}</p>
                <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">
                  <div>${hargaExtra}</div>
                  <div style="font-size:0.75rem;color:#888;"><i class="bi bi-geo-alt me-1"></i>${escHtml(v.lokasi)}</div>
                </div>
              </div>
            </div>
          </div>
        </div>`;
    });
    html += '</div>';
    body.innerHTML = html;
}

function selectVendorCard(el, id, nama, harga, satuan) {
    document.querySelectorAll('.vendor-pick-card').forEach(c => c.classList.remove('selected'));
    el.classList.add('selected');
    tempSelected = { id, nama, harga, satuan };
}

function confirmVendor() {
    if (!tempSelected || !currentFasilitas) { modal.hide(); return; }
    const { idx, label } = currentFasilitas;

    selectedVendors[idx] = { ...tempSelected, fasilitas: label };

    // Update fasilitas item UI
    const item = document.getElementById('fasilitas-' + idx);
    item.classList.add('vendor-selected');
    document.getElementById('selected-name-' + idx).textContent = '→ ' + tempSelected.nama;

    updatePriceSummary();
    modal.hide();
}

function updatePriceSummary() {
    const keys = Object.keys(selectedVendors);
    const summary = document.getElementById('selectionSummary');
    const summaryList = document.getElementById('summaryList');
    const addonList = document.getElementById('addonList');
    const vendorAddons = document.getElementById('vendorAddons');

    if (keys.length === 0) {
        summary.style.display = 'none';
        vendorAddons.style.display = 'none';
        return;
    }

    let total = baseHarga;
    let summaryHtml = '';
    let addonHtml = '';

    keys.forEach(idx => {
        const sv = selectedVendors[idx];
        total += sv.harga;
        summaryHtml += `
          <div class="d-flex justify-content-between align-items-center mb-2 pb-2" style="border-bottom:1px solid rgba(105,27,27,0.1);">
            <div>
              <div style="font-size:0.78rem;color:#888;">${escHtml(sv.fasilitas)}</div>
              <div style="font-weight:600;font-size:0.88rem;color:var(--maroon);">${escHtml(sv.nama)}</div>
            </div>
            <div style="font-size:0.82rem;color:var(--maroon);">${sv.harga > 0 ? '+' + formatRp(sv.harga) : 'Termasuk'}</div>
          </div>`;
        if (sv.harga > 0) {
            addonHtml += `<div>+ ${escHtml(sv.nama)}: ${formatRp(sv.harga)}</div>`;
        }
    });

    summaryList.innerHTML = summaryHtml;
    summary.style.display = 'block';

    if (addonHtml) {
        addonList.innerHTML = addonHtml;
        document.getElementById('totalHarga').textContent = formatRp(total);
        vendorAddons.style.display = 'block';
    }
}

function resetVendors() {
    selectedVendors = {};
    document.querySelectorAll('.fasilitas-item').forEach(el => el.classList.remove('vendor-selected'));
    document.querySelectorAll('[id^="selected-name-"]').forEach(el => el.textContent = '');
    document.getElementById('selectionSummary').style.display = 'none';
    document.getElementById('vendorAddons').style.display = 'none';
}

// ── HELPERS ────────────────────────────────────────────────
function formatRp(n) {
    return 'Rp ' + Number(n).toLocaleString('id-ID');
}
function escHtml(s) {
    return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
function escJs(s) {
    return String(s).replace(/'/g,"\\'").replace(/\\/g,'\\\\');
}
</script>
</body>
</html>
