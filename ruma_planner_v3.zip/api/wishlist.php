<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/koneksi.php';
require_once __DIR__ . '/../includes/session.php';
header('Content-Type: application/json');
if (!isLoggedIn()) { echo json_encode(['login_required'=>true]); exit(); }
$data = json_decode(file_get_contents('php://input'), true);
$vendor_id = (int)($data['vendor_id'] ?? 0);
if (!$vendor_id) { echo json_encode(['error'=>'Invalid']); exit(); }
$cek = $pdo->prepare("SELECT id FROM vendor_wishlist WHERE id_vendor=? AND id_user=?");
$cek->execute([$vendor_id, $_SESSION['user_id']]);
if ($cek->fetch()) {
    $pdo->prepare("DELETE FROM vendor_wishlist WHERE id_vendor=? AND id_user=?")->execute([$vendor_id, $_SESSION['user_id']]);
    echo json_encode(['action'=>'removed']);
} else {
    $pdo->prepare("INSERT OR IGNORE INTO vendor_wishlist (id_vendor,id_user) VALUES (?,?)")->execute([$vendor_id, $_SESSION['user_id']]);
    echo json_encode(['action'=>'added']);
}
