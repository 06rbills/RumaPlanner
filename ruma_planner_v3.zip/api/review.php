<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/koneksi.php';
require_once __DIR__ . '/../includes/session.php';
if (!isLoggedIn()) { header('Location: '.BASE_URL.'login.php'); exit(); }
$vendor_id = (int)($_POST['vendor_id'] ?? 0);
$rating    = min(5, max(1, (int)($_POST['rating'] ?? 5)));
$komentar  = sanitize($pdo, $_POST['komentar'] ?? '');
if ($vendor_id && $komentar) {
    $pdo->prepare("INSERT INTO vendor_review (id_vendor,id_user,rating,komentar) VALUES (?,?,?,?)")->execute([$vendor_id, $_SESSION['user_id'], $rating, $komentar]);
    $avg = $pdo->prepare("SELECT AVG(rating), COUNT(*) FROM vendor_review WHERE id_vendor=?");
    $avg->execute([$vendor_id]); $row = $avg->fetch(PDO::FETCH_NUM);
    $pdo->prepare("UPDATE vendor SET rating=?, total_review=? WHERE id=?")->execute([round($row[0],1), $row[1], $vendor_id]);
}
header('Location: '.BASE_URL.'vendor-detail.php?id='.$vendor_id.'#kalender');
exit();
