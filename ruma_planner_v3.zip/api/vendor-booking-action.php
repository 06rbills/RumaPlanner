<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/koneksi.php';
require_once __DIR__ . '/../includes/session.php';
requireAdmin();
$id     = (int)($_POST['id'] ?? 0);
$action = trim($_POST['action'] ?? '');
if ($id && in_array($action, ['confirm','cancel'])) {
    $status = $action === 'confirm' ? 'confirmed' : 'cancelled';
    $pdo->prepare("UPDATE vendor_booking SET status=? WHERE id=?")->execute([$status, $id]);
}
header('Location: '.BASE_URL.'admin/vendor.php');
exit();
