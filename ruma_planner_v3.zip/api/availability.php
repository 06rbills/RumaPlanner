<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/koneksi.php';
header('Content-Type: application/json');
$tanggal = trim($_GET['tanggal'] ?? '');
if (!$tanggal) { echo json_encode(['error'=>'No date']); exit(); }
// Get all vendors with their status for this date
$stmt = $pdo->query("SELECT v.id, v.nama, v.id_kategori, vk.nama AS kategori, vk.icon FROM vendor v JOIN vendor_kategori vk ON v.id_kategori=vk.id WHERE v.is_active=1");
$vendors = $stmt->fetchAll();
$result = [];
foreach ($vendors as $v) {
    $cek = $pdo->prepare("SELECT status FROM vendor_booking WHERE id_vendor=? AND tanggal=? AND status IN ('confirmed','pending')");
    $cek->execute([$v['id'], $tanggal]);
    $booking = $cek->fetch();
    $result[] = [
        'id'       => $v['id'],
        'nama'     => $v['nama'],
        'kategori' => $v['kategori'],
        'icon'     => $v['icon'],
        'status'   => $booking ? $booking['status'] : 'available',
    ];
}
echo json_encode($result);
