<?php
require_once 'includes/config.php';
require_once 'includes/koneksi.php';
require_once 'includes/session.php';

if (isLoggedIn()) {
    header('Location: ' . (isAdmin() ? BASE_URL . 'admin/dashboard.php' : BASE_URL . 'index.php'));
    exit();
}

$error = '';

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    requireCsrf();
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($username) || empty($password)) {
        $error = 'Username dan password tidak boleh kosong.';
    } else {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username=? OR email=? LIMIT 1");
        $stmt->execute([$username, $username]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            session_regenerate_id(true);
            $_SESSION['user_id']  = $user['id'];
            $_SESSION['nama']     = $user['nama'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['role']     = $user['role'];

            setFlash('success', 'Selamat datang kembali, ' . $user['nama'] . '!');

            if ($user['role'] === 'admin') {
                header('Location: ' . BASE_URL . 'admin/dashboard.php');
            } else {
                $redirect = $_GET['redirect'] ?? '';
                $safe = $redirect && strpos($redirect, '://') === false && strpos($redirect, '//') !== 0;
                header('Location: ' . ($safe ? $redirect : BASE_URL . 'index.php'));
            }
            exit();
        } else {
            $error = 'Username/email atau password salah.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Masuk — <?= SITE_NAME ?></title>
    <link rel="shortcut icon" href="<?= BASE_URL ?>assets/images/icon.jpg">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
</head>
<body>
<div class="auth-page">
    <div class="auth-card text-center">
        <a href="<?= BASE_URL ?>index.php">
            <img src="<?= BASE_URL ?>assets/images/logo.jpg" alt="Ruma Planner" class="auth-logo">
        </a>
        <h2 class="auth-title">Selamat Datang</h2>
        <p style="color:#888;font-size:0.9rem;margin-bottom:28px;">Masuk ke akun Ruma Planner Anda</p>

        <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <i class="bi bi-exclamation-circle me-2"></i><?= htmlspecialchars($error) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>
        <?php showFlash(); ?>

        <form method="POST" class="text-start" novalidate>
            <?= csrfField() ?>
            <div class="mb-3">
                <label class="form-label">Username atau Email</label>
                <div class="input-group">
                    <span class="input-group-text auth-icon"><i class="bi bi-person" style="color:var(--maroon);"></i></span>
                    <input type="text" name="username" class="form-control"
                           placeholder="Masukkan username atau email"
                           value="<?= htmlspecialchars($_POST['username'] ?? '') ?>" required autofocus>
                </div>
            </div>
            <div class="mb-4">
                <label class="form-label">Password</label>
                <div class="input-group">
                    <span class="input-group-text auth-icon"><i class="bi bi-lock" style="color:var(--maroon);"></i></span>
                    <input type="password" name="password" id="passwordInput" class="form-control auth-pass"
                           placeholder="Masukkan password" required>
                    <span class="input-group-text auth-icon" style="cursor:pointer;" onclick="togglePassword('passwordInput','toggleIcon')">
                        <i class="bi bi-eye" id="toggleIcon" style="color:#888;"></i>
                    </span>
                </div>
            </div>
            <div class="d-grid">
                <button type="submit" class="btn btn-maroon" style="padding:14px;">
                    <i class="bi bi-box-arrow-in-right me-2"></i>Masuk
                </button>
            </div>
        </form>

        <div class="mt-4 pt-3" style="border-top:1px solid #f0eeec;">
            <p style="font-size:0.88rem;color:#888;margin:0;">
                Belum punya akun?
                <a href="<?= BASE_URL ?>register.php" style="color:var(--maroon);font-weight:600;text-decoration:none;">Daftar Sekarang</a>
            </p>
        </div>


    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
function togglePassword(inputId, iconId) {
    const input = document.getElementById(inputId);
    const icon = document.getElementById(iconId);
    if (input.type === 'password') { input.type = 'text'; icon.className = 'bi bi-eye-slash'; }
    else { input.type = 'password'; icon.className = 'bi bi-eye'; }
}
</script>
</body>
</html>
