<?php
/**
 * Router untuk PHP Built-in Web Server
 * Jalankan dengan: php -S localhost:8080 router.php
 * (dari dalam folder ruma_planner_final)
 */

$uri = urldecode(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH));

// Sajikan file statis langsung (CSS, JS, gambar, dll)
if ($uri !== '/' && file_exists(__DIR__ . $uri)) {
    // Tentukan MIME type untuk file statis
    $ext = strtolower(pathinfo($uri, PATHINFO_EXTENSION));
    $mimes = [
        'css'  => 'text/css',
        'js'   => 'application/javascript',
        'jpg'  => 'image/jpeg',
        'jpeg' => 'image/jpeg',
        'png'  => 'image/png',
        'gif'  => 'image/gif',
        'webp' => 'image/webp',
        'ico'  => 'image/x-icon',
        'svg'  => 'image/svg+xml',
        'woff' => 'font/woff',
        'woff2'=> 'font/woff2',
        'ttf'  => 'font/ttf',
    ];
    if (isset($mimes[$ext])) {
        header('Content-Type: ' . $mimes[$ext]);
        readfile(__DIR__ . $uri);
        return true;
    }
    return false; // PHP akan menangani file PHP
}

// Default ke index.php
if ($uri === '/') {
    require __DIR__ . '/index.php';
    return true;
}

return false;
