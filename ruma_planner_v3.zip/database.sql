-- =====================================================
-- DATABASE: Sistem Informasi Wedding Organizer
-- Ruma Planner - by Riski Nang Bayu
-- =====================================================

CREATE DATABASE IF NOT EXISTS ruma_planner_fix CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE ruma_planner_fix;

-- =====================================================
-- TABLE: users
-- =====================================================
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama VARCHAR(100) NOT NULL,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    no_hp VARCHAR(20),
    role ENUM('client', 'admin') DEFAULT 'client',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- =====================================================
-- TABLE: paket
-- =====================================================
CREATE TABLE IF NOT EXISTS paket (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama_paket VARCHAR(100) NOT NULL,
    kategori ENUM('Intimate', 'Reguler', 'Premium', 'Exclusive') NOT NULL,
    harga DECIMAL(15,2) NOT NULL,
    deskripsi TEXT,
    fasilitas TEXT,
    foto VARCHAR(255),
    max_tamu INT DEFAULT 100,
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- =====================================================
-- TABLE: booking
-- =====================================================
CREATE TABLE IF NOT EXISTS booking (
    id INT AUTO_INCREMENT PRIMARY KEY,
    kode_booking VARCHAR(20) NOT NULL UNIQUE,
    id_user INT NOT NULL,
    id_paket INT NOT NULL,
    nama_mempelai_pria VARCHAR(100) NOT NULL,
    nama_mempelai_wanita VARCHAR(100) NOT NULL,
    tanggal_acara DATE NOT NULL,
    lokasi TEXT NOT NULL,
    jumlah_tamu INT NOT NULL,
    catatan TEXT,
    total_harga DECIMAL(15,2) NOT NULL,
    dp_amount DECIMAL(15,2) DEFAULT 0,
    bukti_pembayaran VARCHAR(255),
    status ENUM('Pending', 'Diproses', 'Lunas', 'Selesai', 'Dibatalkan') DEFAULT 'Pending',
    catatan_admin TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (id_user) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (id_paket) REFERENCES paket(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- =====================================================
-- TABLE: kontak
-- =====================================================
CREATE TABLE IF NOT EXISTS kontak (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama VARCHAR(100) NOT NULL,
    email VARCHAR(100),
    no_hp VARCHAR(20) NOT NULL,
    pesan TEXT NOT NULL,
    is_read TINYINT(1) DEFAULT 0,
    tanggal TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- =====================================================
-- DEFAULT DATA: Admin Account
-- Username: admin | Password: admin123
-- =====================================================
INSERT INTO users (nama, username, email, password, role) VALUES
('Administrator', 'admin', 'admin@rumaplanner.com', '$2y$12$MXqUrkJ4ylBot6LBzxnpDeTgqXSLy1soThbx7AzeHfQy3/wOk1Dk6', 'admin');

-- =====================================================
-- DEFAULT DATA: Sample Packages
-- =====================================================
INSERT INTO paket (nama_paket, kategori, harga, deskripsi, fasilitas, foto, max_tamu) VALUES
('Intimate Wedding', 'Intimate', 15000000, 'Paket pernikahan intimate untuk momen sakral bersama orang-orang terkasih. Cocok untuk perayaan kecil yang penuh makna dan kehangatan.', 'Dekorasi Minimalis Premium|Dokumentasi Foto & Video|MC Profesional|Catering 50 Pax|Bunga Segar|Sound System|Koordinator Hari H', 'paket_1.jpg', 50),
('Silver Wedding', 'Reguler', 35000000, 'Paket pernikahan reguler dengan dekorasi elegan dan layanan lengkap. Pilihan terbaik untuk pernikahan berkesan dengan budget yang terencana.', 'Dekorasi Elegan|Foto & Video Cinematic|MC Profesional|Catering 150 Pax|Bunga Segar|Pelaminan|Sound System|Lighting|Koordinator|Undangan Digital', 'paket_2.jpg', 150),
('Gold Wedding', 'Premium', 65000000, 'Paket premium dengan sentuhan mewah dan tim profesional berpengalaman. Setiap detail diperhatikan untuk menciptakan pernikahan impian Anda.', 'Dekorasi Mewah Premium|Foto & Video Full Package|MC & Entertainer|Catering 300 Pax|Bunga Import|Pelaminan Custom|Sound System Premium|Lighting Show|Wedding Organizer Full|Undangan Fisik & Digital|Souvenir', 'paket_3.jpg', 300),
('Royal Wedding', 'Exclusive', 120000000, 'Pengalaman pernikahan eksklusif layaknya keluarga kerajaan. Layanan all-inclusive dengan tim dedicated untuk mewujudkan setiap impian Anda menjadi kenyataan.', 'Dekorasi Royal Exclusive|Foto & Video International Style|MC Celebrity|Catering 500 Pax Premium|Bunga Import Rare|Pelaminan Grand Custom|Sound System Concert Grade|Lighting & Pyrotechnic|Full Wedding Organizer|Undangan Eksklusif|Souvenir Premium|Honeymoon Package|Bridal Package|Live Music', 'paket_4.jpg', 500);

-- =====================================================
-- DEFAULT DATA: Sample Client
-- Username: budi | Password: client123
-- =====================================================
INSERT INTO users (nama, username, email, password, no_hp, role) VALUES
('Budi Santoso', 'budi', 'budi@email.com', '$2y$12$2flIJxtYSHL7kZdHcb0hEexkEKyVLd9kCUbWGbUmRDLS2MCs7xb8q', '081234567890', 'client');

-- =====================================================
-- UPGRADE: Multi-Vendor System
-- =====================================================

CREATE TABLE IF NOT EXISTS vendor_kategori (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama VARCHAR(100) NOT NULL,
    slug VARCHAR(100) NOT NULL UNIQUE,
    icon VARCHAR(50) DEFAULT 'bi-person-badge',
    urutan INT DEFAULT 0
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS vendor (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_kategori INT NOT NULL,
    nama VARCHAR(150) NOT NULL,
    slug VARCHAR(150) NOT NULL UNIQUE,
    deskripsi TEXT,
    harga_mulai DECIMAL(15,2) DEFAULT 0,
    harga_satuan VARCHAR(50) DEFAULT 'per acara',
    foto_utama VARCHAR(255),
    gallery TEXT,
    rating DECIMAL(3,1) DEFAULT 5.0,
    total_review INT DEFAULT 0,
    total_booking INT DEFAULT 0,
    no_wa VARCHAR(30),
    instagram VARCHAR(100),
    lokasi VARCHAR(200),
    badge VARCHAR(50) DEFAULT '',
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_kategori) REFERENCES vendor_kategori(id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS vendor_booking (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_booking INT,
    id_vendor INT NOT NULL,
    id_user INT NOT NULL,
    tanggal DATE NOT NULL,
    status ENUM('pending','confirmed','cancelled') DEFAULT 'pending',
    catatan TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_vendor) REFERENCES vendor(id),
    FOREIGN KEY (id_user) REFERENCES users(id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS vendor_review (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_vendor INT NOT NULL,
    id_user INT NOT NULL,
    rating TINYINT DEFAULT 5,
    komentar TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_vendor) REFERENCES vendor(id),
    FOREIGN KEY (id_user) REFERENCES users(id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS vendor_wishlist (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_vendor INT NOT NULL,
    id_user INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_wishlist (id_vendor, id_user),
    FOREIGN KEY (id_vendor) REFERENCES vendor(id),
    FOREIGN KEY (id_user) REFERENCES users(id)
) ENGINE=InnoDB;

-- Sample vendor categories
INSERT IGNORE INTO vendor_kategori (nama, slug, icon, urutan) VALUES
('MUA / Make Up Artist','mua','bi-brush',1),
('Photographer','photographer','bi-camera',2),
('Gedung / Venue','gedung','bi-building',3),
('Catering','catering','bi-cup-hot',4),
('Dekorasi','dekorasi','bi-flower1',5),
('Musik / Band','musik','bi-music-note-beamed',6),
('MC','mc','bi-mic',7),
('Videografer','videografer','bi-camera-video',8);
