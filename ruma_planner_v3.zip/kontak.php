<?php
require_once 'includes/config.php';
require_once 'includes/koneksi.php';
require_once 'includes/session.php';

$success = '';
$error = '';

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    requireCsrf();
    $nama  = sanitize($pdo, $_POST['nama'] ?? '');
    $email = sanitize($pdo, $_POST['email'] ?? '');
    $no_hp = sanitize($pdo, $_POST['no_hp'] ?? '');
    $pesan = sanitize($pdo, $_POST['pesan'] ?? '');

    if (empty($nama) || empty($no_hp) || empty($pesan)) {
        $error = 'Nama, nomor HP, dan pesan wajib diisi.';
    } else {
        $stmt = $pdo->prepare("INSERT INTO kontak (nama, email, no_hp, pesan) VALUES (?,?,?,?)");
        if ($stmt->execute([$nama, $email, $no_hp, $pesan])) {
            $success = 'Pesan berhasil dikirim! Kami akan menghubungi Anda segera.';
        } else {
            $error = 'Gagal mengirim pesan. Silakan coba lagi.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kontak — <?= SITE_NAME ?></title>
    <link rel="shortcut icon" href="<?= BASE_URL ?>assets/images/icon.jpg">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
</head>
<body>
<?php include 'includes/navbar.php'; ?>

<div class="page-header" style="padding-top:100px;">
    <div class="container">
        <h1>Hubungi Kami</h1>
        <p style="color:rgba(255,255,255,0.75);margin-top:8px;">Kami siap membantu mewujudkan pernikahan impian Anda</p>
    </div>
</div>

<section class="section-padding">
    <div class="container">
        <div class="row g-5">
            <div class="col-lg-4">
                <h3 style="font-family:var(--font-display);color:var(--maroon);margin-bottom:8px;">Ruma Planner</h3>
                <p style="color:#666;margin-bottom:32px;font-size:0.9rem;">
                    Kami dengan senang hati siap melayani konsultasi pernikahan Anda. Hubungi kami kapan saja.
                </p>
                <?php
                $contacts = [
                    ['icon'=>'bi-geo-alt-fill','label'=>'Alamat','value'=>ADDRESS],
                    ['icon'=>'bi-telephone-fill','label'=>'Telepon','value'=>PHONE],
                    ['icon'=>'bi-envelope-fill','label'=>'Email','value'=>EMAIL_SITE],
                    ['icon'=>'bi-instagram','label'=>'Instagram','value'=>INSTAGRAM],
                ];
                foreach ($contacts as $c):
                ?>
                <div class="d-flex gap-3 mb-4">
                    <div style="width:44px;height:44px;background:var(--maroon-pale);border-radius:10px;display:flex;align-items:center;justify-content:center;min-width:44px;">
                        <i class="bi <?= $c['icon'] ?>" style="color:var(--maroon);font-size:1.1rem;"></i>
                    </div>
                    <div>
                        <div style="font-size:0.78rem;color:#888;text-transform:uppercase;letter-spacing:0.5px;"><?= $c['label'] ?></div>
                        <div style="font-weight:500;color:var(--text-dark);"><?= $c['value'] ?></div>
                    </div>
                </div>
                <?php endforeach; ?>

                <div class="p-4 rounded-xl mt-3" style="background:linear-gradient(135deg,var(--maroon-dark),var(--maroon));color:white;">
                    <h6 style="font-family:var(--font-display);font-size:1rem;margin-bottom:8px;">Jam Operasional</h6>
                    <div style="font-size:0.85rem;opacity:0.85;">
                        <div class="d-flex justify-content-between mb-1"><span>Senin - Jumat</span><span>08:00 - 17:00</span></div>
                        <div class="d-flex justify-content-between mb-1"><span>Sabtu</span><span>09:00 - 15:00</span></div>
                        <div class="d-flex justify-content-between"><span>Minggu</span><span style="color:rgba(255,255,255,0.5);">Tutup</span></div>
                    </div>
                </div>
            </div>
            <div class="col-lg-8">
                <div class="form-card">
                    <h4 style="font-family:var(--font-display);color:var(--maroon);margin-bottom:24px;">Kirim Pesan</h4>

                    <?php if ($success): ?>
                    <div class="alert alert-success alert-auto-dismiss">
                        <i class="bi bi-check-circle me-2"></i><?= $success ?>
                    </div>
                    <?php endif; ?>
                    <?php if ($error): ?>
                    <div class="alert alert-danger">
                        <i class="bi bi-exclamation-circle me-2"></i><?= $error ?>
                    </div>
                    <?php endif; ?>

                    <form method="POST" class="needs-validation" novalidate>
                        <?= csrfField() ?>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">Nama Lengkap <span class="text-danger">*</span></label>
                                <input type="text" name="nama" class="form-control" placeholder="Nama Anda"
                                       value="<?= htmlspecialchars($_POST['nama'] ?? (isset($_SESSION['nama']) ? $_SESSION['nama'] : '')) ?>" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">No. HP <span class="text-danger">*</span></label>
                                <input type="text" name="no_hp" class="form-control" placeholder="08xxxxxxxxxx"
                                       value="<?= htmlspecialchars($_POST['no_hp'] ?? '') ?>" required>
                            </div>
                            <div class="col-12">
                                <label class="form-label">Email</label>
                                <input type="email" name="email" class="form-control" placeholder="email@contoh.com"
                                       value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
                            </div>
                            <div class="col-12">
                                <label class="form-label">Pesan / Pertanyaan <span class="text-danger">*</span></label>
                                <textarea name="pesan" class="form-control" rows="6" 
                                          placeholder="Tuliskan pertanyaan atau kebutuhan Anda..." required><?= htmlspecialchars($_POST['pesan'] ?? '') ?></textarea>
                            </div>
                            <div class="col-12">
                                <button type="submit" class="btn btn-maroon px-5">
                                    <i class="bi bi-send me-2"></i>Kirim Pesan
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>

<!-- Floating WhatsApp -->
<a href="https://wa.me/6281234567890?text=Halo%2C%20saya%20ingin%20bertanya%20mengenai%20paket%20wedding%20Ruma%20Planner." target="_blank" class="wa-float" title="Chat Admin Ruma Planner"><i class="bi bi-whatsapp"></i></a>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= BASE_URL ?>assets/js/main.js"></script>
</body>
</html>
