<?php
require_once 'includes/config.php';
require_once 'includes/koneksi.php';
require_once 'includes/session.php';
requireLogin();

$vendor_id   = (int)($_GET['vendor'] ?? 0);
$tanggal_pre = trim($_GET['tanggal'] ?? '');

if (!$vendor_id) { header('Location: '.BASE_URL.'vendor.php'); exit(); }

$stmt = $pdo->prepare("SELECT v.*, vk.nama AS nama_kategori FROM vendor v JOIN vendor_kategori vk ON v.id_kategori=vk.id WHERE v.id=? AND v.is_active=1");
$stmt->execute([$vendor_id]);
$vendor = $stmt->fetch();
if (!$vendor) { header('Location: '.BASE_URL.'vendor.php'); exit(); }

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    requireCsrf();
    $tanggal = trim($_POST['tanggal'] ?? '');
    $catatan = sanitize($pdo, $_POST['catatan'] ?? '');
    if (!$tanggal || strtotime($tanggal) <= time()) {
        $error = 'Tanggal tidak valid.';
    } else {
        // Cek apakah sudah dibooking
        $cek = $pdo->prepare("SELECT id FROM vendor_booking WHERE id_vendor=? AND tanggal=? AND status='confirmed'");
        $cek->execute([$vendor_id, $tanggal]);
        if ($cek->fetch()) {
            $error = 'Maaf, tanggal ini sudah Full Booked oleh vendor. Silakan pilih tanggal lain.';
        } else {
            $ins = $pdo->prepare("INSERT INTO vendor_booking (id_vendor,id_user,tanggal,status,catatan) VALUES (?,?,?,'pending',?)");
            $ins->execute([$vendor_id, $_SESSION['user_id'], $tanggal, $catatan]);
            $booking_id = $pdo->lastInsertId();
            // Update total_booking vendor
            $pdo->prepare("UPDATE vendor SET total_booking=total_booking+1 WHERE id=?")->execute([$vendor_id]);
            setFlash('success', 'Booking vendor berhasil! Silakan konfirmasi via WhatsApp vendor.');
            header('Location: '.BASE_URL.'client/riwayat.php');
            exit();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Booking Vendor — <?= SITE_NAME ?></title>
<link rel="shortcut icon" href="<?= BASE_URL ?>assets/images/icon.jpg">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
<link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
</head>
<body>
<?php include 'includes/navbar.php'; ?>
<div class="page-header" style="padding-top:100px;">
  <div class="container">
    <h1>Booking Vendor</h1>
    <p style="color:rgba(255,255,255,0.75);">Konfirmasi jadwal vendor pilihan Anda</p>
  </div>
</div>
<section class="section-padding">
<div class="container">
<div class="row justify-content-center">
<div class="col-lg-7">
<?php if ($error): ?><div class="alert alert-danger"><i class="bi bi-exclamation-circle me-2"></i><?= $error ?></div><?php endif; ?>
<div class="p-4 rounded-xl mb-4" style="background:linear-gradient(135deg,var(--maroon-dark),var(--maroon));color:#fff;">
  <div class="d-flex gap-3 align-items-center">
    <div style="width:56px;height:56px;background:rgba(255,255,255,0.15);border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:1.5rem;flex-shrink:0;">
      <i class="bi bi-person-badge"></i>
    </div>
    <div>
      <div style="font-size:0.75rem;opacity:0.7;text-transform:uppercase;">Vendor Dipilih</div>
      <h4 style="font-family:var(--font-display);margin:2px 0;"><?= htmlspecialchars($vendor['nama']) ?></h4>
      <span style="background:rgba(255,255,255,0.2);padding:2px 10px;border-radius:50px;font-size:0.75rem;"><?= htmlspecialchars($vendor['nama_kategori']) ?></span>
    </div>
    <div class="ms-auto text-end">
      <div style="font-size:0.75rem;opacity:0.7;">Mulai dari</div>
      <div style="font-family:var(--font-display);font-size:1.4rem;color:var(--gold);font-weight:700;"><?= formatRupiah($vendor['harga_mulai']) ?></div>
    </div>
  </div>
</div>
<div class="form-card">
  <h5 style="font-family:var(--font-display);color:var(--maroon);margin-bottom:20px;"><i class="bi bi-calendar-plus me-2"></i>Isi Data Booking</h5>
  <form method="POST">
    <?= csrfField() ?>
    <div class="mb-3">
      <label class="form-label">Tanggal Wedding <span class="text-danger">*</span></label>
      <input type="date" name="tanggal" class="form-control" value="<?= htmlspecialchars($tanggal_pre ?: ($_POST['tanggal'] ?? '')) ?>" min="<?= date('Y-m-d', strtotime('+7 days')) ?>" required>
    </div>
    <div class="mb-3">
      <label class="form-label">Catatan / Permintaan Khusus</label>
      <textarea name="catatan" class="form-control" rows="3" placeholder="Contoh: tema pernikahan, detail khusus, dll."><?= htmlspecialchars($_POST['catatan'] ?? '') ?></textarea>
    </div>
    <div class="p-3 rounded-xl mb-4" style="background:var(--maroon-pale);border:1px solid rgba(105,27,27,0.1);">
      <small><i class="bi bi-info-circle me-1 text-maroon"></i><strong>Info:</strong> Booking vendor akan berstatus <em>Pending</em> hingga dikonfirmasi. Silakan hubungi vendor via WhatsApp untuk kepastian.</small>
    </div>
    <div class="d-flex gap-3">
      <a href="vendor-detail.php?id=<?= $vendor_id ?>" class="btn btn-outline-maroon"><i class="bi bi-arrow-left me-1"></i>Kembali</a>
      <button type="submit" class="btn btn-maroon flex-grow-1"><i class="bi bi-check-circle me-1"></i>Konfirmasi Booking</button>
    </div>
  </form>
  <hr>
  <a href="https://wa.me/<?= preg_replace('/[^0-9]/','', $vendor['no_wa']) ?>?text=<?= urlencode('Halo '.$vendor['nama'].', saya ingin booking untuk tanggal '.($tanggal_pre ?: '...').' apakah masih tersedia?') ?>" target="_blank" class="btn btn-outline-maroon w-100">
    <i class="bi bi-whatsapp me-1"></i>Atau Langsung Chat via WhatsApp
  </a>
</div>
</div></div>
</div>
</section>
<?php include 'includes/footer.php'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body></html>
