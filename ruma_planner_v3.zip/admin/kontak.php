<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/koneksi.php';
require_once __DIR__ . '/../includes/session.php';
requireAdmin();

// Mark as read
if (isset($_GET['read']) && is_numeric($_GET['read'])) {
    $pdo->prepare("UPDATE kontak SET is_read=1 WHERE id=?")->execute([(int)$_GET['read']]);
    header('Location: kontak.php'); exit();
}
// Delete
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $pdo->prepare("DELETE FROM kontak WHERE id=?")->execute([(int)$_GET['delete']]);
    setFlash('success', 'Pesan berhasil dihapus.');
    header('Location: kontak.php'); exit();
}

$kontaks = $pdo->query("SELECT * FROM kontak ORDER BY tanggal DESC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pesan Masuk — <?= SITE_NAME ?></title>
    <link rel="shortcut icon" href="<?= BASE_URL ?>assets/images/icon.jpg">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
</head>
<body>
<?php include 'sidebar.php'; ?>
<div class="admin-main">
    <div class="admin-topbar">
        <div class="d-flex align-items-center gap-3">
            <button class="btn btn-sm d-lg-none" id="sidebarToggle" style="background:var(--maroon-pale);color:var(--maroon);">
                <i class="bi bi-list fs-5"></i>
            </button>
            <div style="font-family:var(--font-display);font-size:1.3rem;color:var(--maroon);font-weight:600;">Pesan Masuk</div>
        </div>
    </div>

    <div class="admin-content">
        <?php showFlash(); ?>

        <div class="row g-4">
            <?php if (empty($kontaks)): ?>
            <div class="col-12 text-center py-5">
                <i class="bi bi-inbox" style="font-size:3rem;color:#ddd;"></i>
                <h5 class="mt-3" style="color:#aaa;">Belum ada pesan masuk</h5>
            </div>
            <?php else: ?>
            <?php foreach ($kontaks as $k): ?>
            <div class="col-md-6">
                <div class="form-card" style="padding:0;overflow:hidden;<?= !$k['is_read'] ? 'border-left:4px solid var(--maroon);' : 'border-left:4px solid #e0e0e0;' ?>">
                    <div class="p-4">
                        <div class="d-flex justify-content-between align-items-start mb-2">
                            <div>
                                <div class="d-flex align-items-center gap-2">
                                    <div style="width:36px;height:36px;background:<?= !$k['is_read'] ? 'var(--maroon)' : '#e0e0e0' ?>;color:white;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:0.85rem;">
                                        <?= strtoupper(substr($k['nama'], 0, 1)) ?>
                                    </div>
                                    <div>
                                        <div style="font-weight:600;font-size:0.92rem;"><?= htmlspecialchars($k['nama']) ?></div>
                                        <div style="font-size:0.75rem;color:#999;"><?= htmlspecialchars($k['no_hp']) ?> · <?= date('d M Y H:i', strtotime($k['tanggal'])) ?></div>
                                    </div>
                                </div>
                            </div>
                            <?php if (!$k['is_read']): ?>
                            <span class="badge bg-danger" style="font-size:0.7rem;">Baru</span>
                            <?php endif; ?>
                        </div>
                        <?php if ($k['email']): ?>
                        <div style="font-size:0.8rem;color:#888;margin-bottom:8px;">
                            <i class="bi bi-envelope me-1"></i><?= htmlspecialchars($k['email']) ?>
                        </div>
                        <?php endif; ?>
                        <div style="font-size:0.88rem;color:#444;line-height:1.7;background:#faf5f5;padding:12px;border-radius:8px;">
                            <?= nl2br(htmlspecialchars($k['pesan'])) ?>
                        </div>
                        <div class="d-flex gap-2 mt-3">
                            <?php if (!$k['is_read']): ?>
                            <a href="kontak.php?read=<?= $k['id'] ?>" class="btn btn-sm btn-outline-success">
                                <i class="bi bi-check2 me-1"></i>Tandai Dibaca
                            </a>
                            <?php endif; ?>
                            <a href="https://wa.me/<?= preg_replace('/[^0-9]/', '', $k['no_hp']) ?>" target="_blank" 
                               class="btn btn-sm btn-maroon">
                                <i class="bi bi-whatsapp me-1"></i>Balas WA
                            </a>
                            <a href="kontak.php?delete=<?= $k['id'] ?>" class="btn btn-sm btn-outline-danger confirm-delete ms-auto">
                                <i class="bi bi-trash"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= BASE_URL ?>assets/js/main.js"></script>
</body>
</html>
