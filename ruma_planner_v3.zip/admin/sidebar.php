<?php if (!defined('BASE_URL')) require_once __DIR__ . '/../includes/config.php'; ?>
<aside class="admin-sidebar" id="adminSidebar">
    <div class="admin-sidebar-logo">
        <a href="<?= BASE_URL ?>admin/dashboard.php">
            <img src="<?= BASE_URL ?>assets/images/logo.jpg" alt="Ruma Planner">
        </a>
        <div style="color:rgba(255,255,255,0.5);font-size:0.72rem;margin-top:6px;letter-spacing:1px;text-transform:uppercase;">Admin Panel</div>
    </div>

    <nav class="admin-nav">
        <div class="admin-nav-section">Utama</div>
        <div class="admin-nav-item">
            <a href="<?= BASE_URL ?>admin/dashboard.php" class="admin-nav-link <?= basename($_SERVER['PHP_SELF']) === 'dashboard.php' ? 'active' : '' ?>">
                <i class="bi bi-speedometer2"></i> Dashboard
            </a>
        </div>

        <div class="admin-nav-section">Manajemen</div>
        <div class="admin-nav-item">
            <a href="<?= BASE_URL ?>admin/paket.php" class="admin-nav-link <?= basename($_SERVER['PHP_SELF']) === 'paket.php' ? 'active' : '' ?>">
                <i class="bi bi-gift"></i> Paket Wedding
            </a>
        </div>
        <div class="admin-nav-item">
            <a href="<?= BASE_URL ?>admin/booking.php" class="admin-nav-link <?= basename($_SERVER['PHP_SELF']) === 'booking.php' ? 'active' : '' ?>">
                <i class="bi bi-calendar-check"></i> Data Booking
            </a>
        </div>
        <div class="admin-nav-item">
            <a href="<?= BASE_URL ?>admin/client.php" class="admin-nav-link <?= basename($_SERVER['PHP_SELF']) === 'client.php' ? 'active' : '' ?>">
                <i class="bi bi-people"></i> Data Client
            </a>
        </div>
        <div class="admin-nav-item">
            <a href="<?= BASE_URL ?>admin/kontak.php" class="admin-nav-link <?= basename($_SERVER['PHP_SELF']) === 'kontak.php' ? 'active' : '' ?>">
                <i class="bi bi-chat-dots"></i> Pesan Masuk
            </a>
        </div>

        <div class="admin-nav-section">Akun</div>
        <div class="admin-nav-item">
            <a href="<?= BASE_URL ?>index.php" class="admin-nav-link" target="_blank">
                <i class="bi bi-house"></i> Lihat Website
            </a>
        </div>
        <div class="admin-nav-item">
            <a href="<?= BASE_URL ?>logout.php" class="admin-nav-link" style="color:rgba(255,100,100,0.8);">
                <i class="bi bi-box-arrow-right"></i> Logout
            </a>
        </div>
    </nav>
</aside>
