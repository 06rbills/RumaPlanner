<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/koneksi.php';
require_once __DIR__ . '/../includes/session.php';
requireAdmin();

// DELETE
if (($_GET['action'] ?? '') === 'delete' && isset($_GET['id'])) {
    $del_id = (int)$_GET['id'];
    $pdo->prepare("DELETE FROM users WHERE id=? AND role='client'")->execute([$del_id]);
    setFlash('success', 'Client berhasil dihapus.');
    header('Location: client.php'); exit();
}

$clients = $pdo->query("
    SELECT u.*, COUNT(b.id) as total_booking, COALESCE(SUM(b.total_harga),0) as total_spent
    FROM users u
    LEFT JOIN booking b ON u.id = b.id_user
    WHERE u.role='client'
    GROUP BY u.id
    ORDER BY u.created_at DESC
")->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Client — <?= SITE_NAME ?></title>
    <link rel="shortcut icon" href="<?= BASE_URL ?>assets/images/icon.jpg">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
</head>
<body>
<?php include 'sidebar.php'; ?>
<div class="admin-main">
    <div class="admin-topbar">
        <div class="d-flex align-items-center gap-3">
            <button class="btn btn-sm d-lg-none" id="sidebarToggle" style="background:var(--maroon-pale);color:var(--maroon);">
                <i class="bi bi-list fs-5"></i>
            </button>
            <div style="font-family:var(--font-display);font-size:1.3rem;color:var(--maroon);font-weight:600;">Data Client</div>
        </div>
        <div style="font-size:0.88rem;color:#888;">Total: <?= count($clients) ?> client terdaftar</div>
    </div>

    <div class="admin-content">
        <?php showFlash(); ?>

        <div class="admin-table-card">
            <div class="table-header">
                <div class="table-title">Daftar Client</div>
            </div>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Nama</th>
                            <th>Username</th>
                            <th>Email</th>
                            <th>No. HP</th>
                            <th>Total Booking</th>
                            <th>Total Transaksi</th>
                            <th>Bergabung</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if (empty($clients)): ?>
                    <tr><td colspan="9" class="text-center text-muted py-4">Belum ada client terdaftar</td></tr>
                    <?php else: ?>
                    <?php foreach ($clients as $i => $c): ?>
                    <tr>
                        <td><?= $i + 1 ?></td>
                        <td>
                            <div class="d-flex align-items-center gap-2">
                                <div style="width:32px;height:32px;background:var(--maroon);color:white;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:0.82rem;font-weight:700;min-width:32px;">
                                    <?= strtoupper(substr($c['nama'], 0, 1)) ?>
                                </div>
                                <span style="font-weight:500;"><?= htmlspecialchars($c['nama']) ?></span>
                            </div>
                        </td>
                        <td style="color:#888;font-size:0.85rem;">@<?= htmlspecialchars($c['username']) ?></td>
                        <td style="font-size:0.85rem;"><?= htmlspecialchars($c['email']) ?></td>
                        <td style="font-size:0.85rem;"><?= htmlspecialchars($c['no_hp'] ?: '-') ?></td>
                        <td class="text-center">
                            <span class="badge" style="background:var(--maroon-pale);color:var(--maroon);"><?= $c['total_booking'] ?></span>
                        </td>
                        <td style="font-weight:600;color:var(--maroon);font-size:0.85rem;"><?= formatRupiah($c['total_spent']) ?></td>
                        <td style="font-size:0.82rem;color:#888;"><?= date('d M Y', strtotime($c['created_at'])) ?></td>
                        <td>
                            <a href="client.php?action=delete&id=<?= $c['id'] ?>" class="btn btn-sm btn-outline-danger confirm-delete" title="Hapus">
                                <i class="bi bi-trash"></i>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= BASE_URL ?>assets/js/main.js"></script>
</body>
</html>
