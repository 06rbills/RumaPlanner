<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/koneksi.php';
require_once __DIR__ . '/../includes/session.php';
requireAdmin();

$vendors = $pdo->query("
    SELECT v.*, vk.nama AS nama_kategori
    FROM vendor v JOIN vendor_kategori vk ON v.id_kategori=vk.id
    ORDER BY vk.urutan, v.nama
")->fetchAll();

$kategoris = $pdo->query("SELECT * FROM vendor_kategori ORDER BY urutan")->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Kelola Vendor — Admin <?= SITE_NAME ?></title>
<link rel="shortcut icon" href="<?= BASE_URL ?>assets/images/icon.jpg">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
<link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
</head>
<body style="background:var(--off-white);">
<?php include 'sidebar.php'; ?>
<div style="margin-left:260px;padding:24px 32px;">
<div class="d-flex justify-content-between align-items-center mb-4">
  <div>
    <h3 style="font-family:var(--font-display);color:var(--maroon);">Kelola Vendor</h3>
    <p class="text-muted mb-0">Manajemen semua vendor wedding</p>
  </div>
  <a href="<?= BASE_URL ?>vendor.php" target="_blank" class="btn btn-maroon">
    <i class="bi bi-eye me-1"></i>Lihat di Website
  </a>
</div>

<?php showFlash(); ?>

<!-- Stats -->
<div class="row g-3 mb-4">
<?php
$total = $pdo->query("SELECT COUNT(*) FROM vendor WHERE is_active=1")->fetchColumn();
$bookings = $pdo->query("SELECT COUNT(*) FROM vendor_booking WHERE status='pending'")->fetchColumn();
$confirmed = $pdo->query("SELECT COUNT(*) FROM vendor_booking WHERE status='confirmed'")->fetchColumn();
?>
<div class="col-md-4"><div class="p-4 rounded-xl bg-white shadow-sm text-center"><div style="font-size:2.5rem;font-family:var(--font-display);color:var(--maroon);"><?= $total ?></div><div class="text-muted">Total Vendor Aktif</div></div></div>
<div class="col-md-4"><div class="p-4 rounded-xl bg-white shadow-sm text-center"><div style="font-size:2.5rem;font-family:var(--font-display);color:#f0ad00;"><?= $bookings ?></div><div class="text-muted">Booking Pending</div></div></div>
<div class="col-md-4"><div class="p-4 rounded-xl bg-white shadow-sm text-center"><div style="font-size:2.5rem;font-family:var(--font-display);color:#28a745;"><?= $confirmed ?></div><div class="text-muted">Booking Confirmed</div></div></div>
</div>

<!-- Vendor Table -->
<div class="bg-white rounded-xl p-4 shadow-sm">
<div class="table-responsive">
<table class="table table-hover align-middle">
<thead style="background:var(--maroon-pale);">
<tr>
  <th>Vendor</th><th>Kategori</th><th>Harga</th><th>Rating</th><th>Booking</th><th>Badge</th><th>Status</th><th>WhatsApp</th>
</tr>
</thead>
<tbody>
<?php foreach ($vendors as $v): ?>
<tr>
  <td><strong><?= htmlspecialchars($v['nama']) ?></strong><br><small class="text-muted"><?= htmlspecialchars($v['lokasi']) ?></small></td>
  <td><span class="badge" style="background:var(--maroon-pale);color:var(--maroon);"><?= htmlspecialchars($v['nama_kategori']) ?></span></td>
  <td style="font-family:var(--font-display);color:var(--maroon);"><?= formatRupiah($v['harga_mulai']) ?></td>
  <td><span style="color:var(--gold);">★</span> <?= number_format($v['rating'],1) ?> <small class="text-muted">(<?= $v['total_review'] ?>)</small></td>
  <td><span class="badge bg-primary"><?= $v['total_booking'] ?>x</span></td>
  <td><?= $v['badge'] ? '<span class="badge bg-warning text-dark">'.htmlspecialchars($v['badge']).'</span>' : '<span class="text-muted">-</span>' ?></td>
  <td><?= $v['is_active'] ? '<span class="badge bg-success">Aktif</span>' : '<span class="badge bg-danger">Nonaktif</span>' ?></td>
  <td><a href="https://wa.me/<?= preg_replace('/[^0-9]/','', $v['no_wa']) ?>" target="_blank" class="btn btn-sm" style="background:#25D366;color:#fff;"><i class="bi bi-whatsapp"></i></a></td>
</tr>
<?php endforeach; ?>
</tbody>
</table>
</div>
</div>

<!-- Vendor Bookings -->
<div class="bg-white rounded-xl p-4 shadow-sm mt-4">
<h5 style="font-family:var(--font-display);color:var(--maroon);margin-bottom:20px;">Booking Vendor Terbaru</h5>
<?php
$vb = $pdo->query("
    SELECT vb.*, v.nama AS vendor_nama, vk.nama AS kategori, u.nama AS nama_user, u.no_hp
    FROM vendor_booking vb
    JOIN vendor v ON vb.id_vendor=v.id
    JOIN vendor_kategori vk ON v.id_kategori=vk.id
    JOIN users u ON vb.id_user=u.id
    ORDER BY vb.created_at DESC LIMIT 20
")->fetchAll();
?>
<div class="table-responsive">
<table class="table table-hover">
<thead style="background:var(--maroon-pale);"><tr><th>Vendor</th><th>Customer</th><th>Tanggal</th><th>Status</th><th>Aksi</th></tr></thead>
<tbody>
<?php foreach ($vb as $b): ?>
<tr>
  <td><strong><?= htmlspecialchars($b['vendor_nama']) ?></strong><br><small class="text-muted"><?= htmlspecialchars($b['kategori']) ?></small></td>
  <td><?= htmlspecialchars($b['nama_user']) ?><br><small class="text-muted"><?= htmlspecialchars($b['no_hp'] ?? '') ?></small></td>
  <td><?= date('d M Y', strtotime($b['tanggal'])) ?></td>
  <td>
    <?php $colors=['pending'=>'warning','confirmed'=>'success','cancelled'=>'danger'];?>
    <span class="badge bg-<?= $colors[$b['status']] ?>"><?= ucfirst($b['status']) ?></span>
  </td>
  <td>
    <?php if ($b['status']==='pending'): ?>
    <form method="POST" action="api/vendor-booking-action.php" class="d-inline">
      <input type="hidden" name="id" value="<?= $b['id'] ?>">
      <input type="hidden" name="action" value="confirm">
      <button type="submit" class="btn btn-sm btn-success"><i class="bi bi-check"></i></button>
    </form>
    <form method="POST" action="api/vendor-booking-action.php" class="d-inline">
      <input type="hidden" name="id" value="<?= $b['id'] ?>">
      <input type="hidden" name="action" value="cancel">
      <button type="submit" class="btn btn-sm btn-danger"><i class="bi bi-x"></i></button>
    </form>
    <?php endif; ?>
  </td>
</tr>
<?php endforeach; ?>
</tbody>
</table>
</div>
</div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
