<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/koneksi.php';
require_once __DIR__ . '/../includes/session.php';
requireAdmin();

$id = (int)($_GET['id'] ?? 0);
if (!$id) { header('Location: booking.php'); exit(); }

$stmt = $pdo->prepare("SELECT b.*, u.nama as nama_client, u.email, u.no_hp, p.nama_paket, p.kategori, p.harga FROM booking b JOIN users u ON b.id_user=u.id JOIN paket p ON b.id_paket=p.id WHERE b.id=?");
$stmt->execute([$id]);
$b = $stmt->fetch();
if (!$b) { header('Location: booking.php'); exit(); }

// Update status
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    requireCsrf();
    $new_status    = sanitize($pdo, $_POST['status']);
    $catatan_admin = sanitize($pdo, $_POST['catatan_admin'] ?? '');
    $stmt = $pdo->prepare("UPDATE booking SET status=?, catatan_admin=? WHERE id=?");
    $stmt->execute([$new_status, $catatan_admin, $id]);
    setFlash('success', 'Status booking berhasil diperbarui.');
    header('Location: booking-detail.php?id=' . $id); exit();
}

$statuses = ['Pending','Diproses','Lunas','Selesai','Dibatalkan'];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Booking — <?= SITE_NAME ?></title>
    <link rel="shortcut icon" href="<?= BASE_URL ?>assets/images/icon.jpg">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
</head>
<body>
<?php include 'sidebar.php'; ?>
<div class="admin-main">
    <div class="admin-topbar">
        <div class="d-flex align-items-center gap-3">
            <button class="btn btn-sm d-lg-none" id="sidebarToggle" style="background:var(--maroon-pale);color:var(--maroon);">
                <i class="bi bi-list fs-5"></i>
            </button>
            <div>
                <a href="booking.php" style="color:var(--maroon);text-decoration:none;font-size:0.82rem;">
                    <i class="bi bi-arrow-left me-1"></i>Kembali
                </a>
                <div style="font-family:var(--font-display);font-size:1.3rem;color:var(--maroon);font-weight:600;">
                    Detail Booking
                </div>
            </div>
        </div>
        <?= statusBadge($b['status']) ?>
    </div>

    <div class="admin-content">
        <?php showFlash(); ?>

        <div class="row g-4">
            <!-- Left: Booking Info -->
            <div class="col-lg-8">
                <!-- Header Card -->
                <div class="p-4 rounded-xl mb-4" style="background:linear-gradient(135deg,var(--maroon-dark),var(--maroon));color:white;">
                    <div class="row align-items-center">
                        <div class="col">
                            <div style="font-size:0.75rem;opacity:0.7;text-transform:uppercase;">Kode Booking</div>
                            <div style="font-size:1.4rem;font-weight:700;letter-spacing:2px;"><?= htmlspecialchars($b['kode_booking']) ?></div>
                            <div style="font-size:0.85rem;opacity:0.75;margin-top:4px;">
                                Dipesan pada <?= date('d F Y H:i', strtotime($b['created_at'])) ?>
                            </div>
                        </div>
                        <div class="col-auto"><?= statusBadge($b['status']) ?></div>
                    </div>
                </div>

                <div class="admin-table-card mb-4">
                    <div class="table-header"><div class="table-title">Data Mempelai & Acara</div></div>
                    <div class="p-4">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <div style="font-size:0.75rem;color:#999;text-transform:uppercase;letter-spacing:0.5px;">Mempelai Pria</div>
                                <div style="font-weight:600;"><?= htmlspecialchars($b['nama_mempelai_pria']) ?></div>
                            </div>
                            <div class="col-md-6">
                                <div style="font-size:0.75rem;color:#999;text-transform:uppercase;letter-spacing:0.5px;">Mempelai Wanita</div>
                                <div style="font-weight:600;"><?= htmlspecialchars($b['nama_mempelai_wanita']) ?></div>
                            </div>
                            <div class="col-md-4">
                                <div style="font-size:0.75rem;color:#999;text-transform:uppercase;letter-spacing:0.5px;">Tanggal Acara</div>
                                <div style="font-weight:600;color:var(--maroon);"><?= date('d F Y', strtotime($b['tanggal_acara'])) ?></div>
                            </div>
                            <div class="col-md-4">
                                <div style="font-size:0.75rem;color:#999;text-transform:uppercase;letter-spacing:0.5px;">Jumlah Tamu</div>
                                <div style="font-weight:600;"><?= $b['jumlah_tamu'] ?> orang</div>
                            </div>
                            <div class="col-md-4">
                                <div style="font-size:0.75rem;color:#999;text-transform:uppercase;letter-spacing:0.5px;">Paket</div>
                                <div style="font-weight:600;"><?= htmlspecialchars($b['nama_paket']) ?> <span class="badge" style="background:var(--maroon-pale);color:var(--maroon);font-size:0.7rem;"><?= $b['kategori'] ?></span></div>
                            </div>
                            <div class="col-12">
                                <div style="font-size:0.75rem;color:#999;text-transform:uppercase;letter-spacing:0.5px;">Lokasi Acara</div>
                                <div style="font-weight:500;"><?= nl2br(htmlspecialchars($b['lokasi'])) ?></div>
                            </div>
                            <?php if ($b['catatan']): ?>
                            <div class="col-12">
                                <div style="font-size:0.75rem;color:#999;text-transform:uppercase;letter-spacing:0.5px;">Catatan dari Client</div>
                                <div style="color:#666;"><?= nl2br(htmlspecialchars($b['catatan'])) ?></div>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- Payment -->
                <div class="admin-table-card">
                    <div class="table-header"><div class="table-title">Pembayaran & Bukti</div></div>
                    <div class="p-4">
                        <div class="row g-3 mb-4">
                            <div class="col-md-4 text-center p-3 rounded-xl" style="background:var(--maroon-pale);">
                                <div style="font-size:0.75rem;color:#888;">Total Harga</div>
                                <div style="font-family:var(--font-display);font-size:1.3rem;color:var(--maroon);font-weight:700;"><?= formatRupiah($b['total_harga']) ?></div>
                            </div>
                            <div class="col-md-4 text-center p-3 rounded-xl" style="background:#fdf6e8;">
                                <div style="font-size:0.75rem;color:#888;">DP (30%)</div>
                                <div style="font-family:var(--font-display);font-size:1.3rem;color:var(--gold);font-weight:700;"><?= formatRupiah($b['dp_amount']) ?></div>
                            </div>
                            <div class="col-md-4 text-center p-3 rounded-xl" style="background:#e8f5ee;">
                                <div style="font-size:0.75rem;color:#888;">Sisa Bayar</div>
                                <div style="font-family:var(--font-display);font-size:1.3rem;color:#198754;font-weight:700;"><?= formatRupiah($b['total_harga'] - $b['dp_amount']) ?></div>
                            </div>
                        </div>
                        <?php if ($b['bukti_pembayaran']): ?>
                        <div>
                            <div style="font-size:0.82rem;color:#888;margin-bottom:8px;">Bukti Pembayaran DP:</div>
                            <img src="<?= UPLOAD_URL_BAYAR . htmlspecialchars($b['bukti_pembayaran']) ?>" 
                                 alt="Bukti Pembayaran" class="img-thumbnail" style="max-height:300px;">
                        </div>
                        <?php else: ?>
                        <div class="alert alert-warning"><i class="bi bi-exclamation-triangle me-2"></i>Client belum mengupload bukti pembayaran.</div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Right: Client Info + Update Status -->
            <div class="col-lg-4">
                <!-- Client Info -->
                <div class="admin-table-card mb-4">
                    <div class="table-header"><div class="table-title">Info Client</div></div>
                    <div class="p-4">
                        <div class="text-center mb-3">
                            <div class="mx-auto d-flex align-items-center justify-content-center rounded-circle mb-2"
                                 style="width:56px;height:56px;background:var(--maroon);color:white;font-family:var(--font-display);font-size:1.5rem;font-weight:700;">
                                <?= strtoupper(substr($b['nama_client'], 0, 1)) ?>
                            </div>
                            <div style="font-weight:600;"><?= htmlspecialchars($b['nama_client']) ?></div>
                        </div>
                        <div class="d-flex gap-2 mb-2 align-items-center">
                            <i class="bi bi-telephone" style="color:var(--maroon);"></i>
                            <span style="font-size:0.88rem;"><?= htmlspecialchars($b['no_hp']) ?></span>
                        </div>
                        <div class="d-flex gap-2 align-items-center">
                            <i class="bi bi-envelope" style="color:var(--maroon);"></i>
                            <span style="font-size:0.88rem;"><?= htmlspecialchars($b['email']) ?></span>
                        </div>
                    </div>
                </div>

                <!-- Update Status -->
                <div class="admin-table-card">
                    <div class="table-header"><div class="table-title">Update Status</div></div>
                    <div class="p-4">
                        <form method="POST">
                            <?= csrfField() ?>
                            <div class="mb-3">
                                <label class="form-label">Status Pesanan</label>
                                <select name="status" class="form-select" required>
                                    <?php foreach ($statuses as $s): ?>
                                    <option value="<?= $s ?>" <?= $b['status'] === $s ? 'selected' : '' ?>><?= $s ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Catatan untuk Client</label>
                                <textarea name="catatan_admin" class="form-control" rows="4" 
                                          placeholder="Catatan verifikasi, instruksi, dll..."><?= htmlspecialchars($b['catatan_admin']) ?></textarea>
                            </div>
                            <div class="d-grid">
                                <button type="submit" class="btn btn-maroon">
                                    <i class="bi bi-check2-circle me-2"></i>Simpan Perubahan
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= BASE_URL ?>assets/js/main.js"></script>
</body>
</html>
