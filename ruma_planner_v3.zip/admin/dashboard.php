<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/koneksi.php';
require_once __DIR__ . '/../includes/session.php';
requireAdmin();

// Stats
$total_booking  = $pdo->query("SELECT COUNT(*) as n FROM booking")->fetch()['n'];
$total_client   = $pdo->query("SELECT COUNT(*) as n FROM users WHERE role='client'")->fetch()['n'];
$total_paket    = $pdo->query("SELECT COUNT(*) as n FROM paket WHERE is_active=1")->fetch()['n'];
$total_pesan    = $pdo->query("SELECT COUNT(*) as n FROM kontak WHERE is_read=0")->fetch()['n'];

$pending  = $pdo->query("SELECT COUNT(*) as n FROM booking WHERE status='Pending'")->fetch()['n'];
$diproses = $pdo->query("SELECT COUNT(*) as n FROM booking WHERE status='Diproses'")->fetch()['n'];
$selesai  = $pdo->query("SELECT COUNT(*) as n FROM booking WHERE status='Selesai'")->fetch()['n'];

$pendapatan = $pdo->query("SELECT COALESCE(SUM(total_harga),0) as total FROM booking WHERE status IN('Lunas','Selesai')")->fetch()['total'];

// Recent bookings
$recent = $pdo->query("SELECT b.*, u.nama as nama_client, p.nama_paket FROM booking b JOIN users u ON b.id_user=u.id JOIN paket p ON b.id_paket=p.id ORDER BY b.created_at DESC LIMIT 8")->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin — <?= SITE_NAME ?></title>
    <link rel="shortcut icon" href="<?= BASE_URL ?>assets/images/icon.jpg">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
</head>
<body>
<?php include 'sidebar.php'; ?>

<div class="admin-main">
    <!-- Topbar -->
    <div class="admin-topbar">
        <div class="d-flex align-items-center gap-3">
            <button class="btn btn-sm d-lg-none" id="sidebarToggle" style="background:var(--maroon-pale);color:var(--maroon);">
                <i class="bi bi-list fs-5"></i>
            </button>
            <div>
                <div style="font-family:var(--font-display);font-size:1.3rem;color:var(--maroon);font-weight:600;">Dashboard</div>
                <div style="font-size:0.78rem;color:#888;">Selamat datang, <?= htmlspecialchars($_SESSION['nama']) ?>!</div>
            </div>
        </div>
        <div class="d-flex align-items-center gap-2">
            <span style="font-size:0.82rem;color:#888;"><?= date('d F Y') ?></span>
            <div style="width:36px;height:36px;background:var(--maroon);color:white;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:700;">
                A
            </div>
        </div>
    </div>

    <div class="admin-content">
        <?php showFlash(); ?>

        <!-- Stat Cards Row 1 -->
        <div class="row g-4 mb-4">
            <div class="col-lg-3 col-md-6">
                <div class="stat-card">
                    <div class="stat-icon"><i class="bi bi-calendar-check"></i></div>
                    <div class="stat-value"><?= $total_booking ?></div>
                    <div class="stat-label">Total Booking</div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="stat-card" style="border-left-color:#c9a96e;">
                    <div class="stat-icon" style="background:#fdf6e8;color:#c9a96e;"><i class="bi bi-people"></i></div>
                    <div class="stat-value" style="color:#c9a96e;"><?= $total_client ?></div>
                    <div class="stat-label">Total Client</div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="stat-card" style="border-left-color:#198754;">
                    <div class="stat-icon" style="background:#e8f5ee;color:#198754;"><i class="bi bi-gift"></i></div>
                    <div class="stat-value" style="color:#198754;"><?= $total_paket ?></div>
                    <div class="stat-label">Paket Aktif</div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="stat-card" style="border-left-color:#0d6efd;">
                    <div class="stat-icon" style="background:#e8f0fe;color:#0d6efd;"><i class="bi bi-chat-dots"></i></div>
                    <div class="stat-value" style="color:#0d6efd;"><?= $total_pesan ?></div>
                    <div class="stat-label">Pesan Belum Dibaca</div>
                </div>
            </div>
        </div>

        <!-- Stat Cards Row 2 -->
        <div class="row g-4 mb-4">
            <div class="col-lg-4 col-md-6">
                <div class="p-4 rounded-xl d-flex align-items-center gap-3" style="background:white;box-shadow:var(--shadow-sm);border-left:4px solid #ffc107;">
                    <div style="width:44px;height:44px;background:#fff8e1;border-radius:10px;display:flex;align-items:center;justify-content:center;color:#ffc107;font-size:1.3rem;min-width:44px;">
                        <i class="bi bi-hourglass-split"></i>
                    </div>
                    <div>
                        <div style="font-size:1.6rem;font-family:var(--font-display);font-weight:700;color:#ffc107;line-height:1;"><?= $pending ?></div>
                        <div style="font-size:0.82rem;color:#888;">Booking Pending</div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="p-4 rounded-xl d-flex align-items-center gap-3" style="background:white;box-shadow:var(--shadow-sm);border-left:4px solid #0dcaf0;">
                    <div style="width:44px;height:44px;background:#e3f9fd;border-radius:10px;display:flex;align-items:center;justify-content:center;color:#0dcaf0;font-size:1.3rem;min-width:44px;">
                        <i class="bi bi-arrow-repeat"></i>
                    </div>
                    <div>
                        <div style="font-size:1.6rem;font-family:var(--font-display);font-weight:700;color:#0dcaf0;line-height:1;"><?= $diproses ?></div>
                        <div style="font-size:0.82rem;color:#888;">Sedang Diproses</div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-12">
                <div class="p-4 rounded-xl d-flex align-items-center gap-3" style="background:linear-gradient(135deg,var(--maroon-dark),var(--maroon));box-shadow:var(--shadow-md);">
                    <div style="width:44px;height:44px;background:rgba(255,255,255,0.15);border-radius:10px;display:flex;align-items:center;justify-content:center;color:var(--gold);font-size:1.3rem;min-width:44px;">
                        <i class="bi bi-cash-coin"></i>
                    </div>
                    <div>
                        <div style="font-size:0.75rem;color:rgba(255,255,255,0.7);text-transform:uppercase;letter-spacing:0.5px;">Total Pendapatan</div>
                        <div style="font-family:var(--font-display);font-size:1.2rem;font-weight:700;color:var(--gold);line-height:1.2;"><?= formatRupiah($pendapatan) ?></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Recent Bookings -->
        <div class="admin-table-card">
            <div class="table-header">
                <div class="table-title">Booking Terbaru</div>
                <a href="booking.php" class="btn btn-maroon btn-sm px-4">Lihat Semua</a>
            </div>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Kode</th>
                            <th>Client</th>
                            <th>Mempelai</th>
                            <th>Paket</th>
                            <th>Tanggal Acara</th>
                            <th>Total</th>
                            <th>Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($recent)): ?>
                        <tr><td colspan="8" class="text-center text-muted py-4">Belum ada data booking</td></tr>
                        <?php else: ?>
                        <?php foreach ($recent as $r): ?>
                        <tr>
                            <td><strong style="color:var(--maroon);font-size:0.8rem;"><?= htmlspecialchars($r['kode_booking']) ?></strong></td>
                            <td><?= htmlspecialchars($r['nama_client']) ?></td>
                            <td style="font-size:0.83rem;"><?= htmlspecialchars($r['nama_mempelai_pria']) ?> & <?= htmlspecialchars($r['nama_mempelai_wanita']) ?></td>
                            <td><span class="badge" style="background:var(--maroon-pale);color:var(--maroon);"><?= htmlspecialchars($r['nama_paket']) ?></span></td>
                            <td><?= date('d M Y', strtotime($r['tanggal_acara'])) ?></td>
                            <td style="font-weight:600;color:var(--maroon);"><?= formatRupiah($r['total_harga']) ?></td>
                            <td><?= statusBadge($r['status']) ?></td>
                            <td>
                                <a href="booking-detail.php?id=<?= $r['id'] ?>" class="btn btn-sm btn-outline-secondary">
                                    <i class="bi bi-eye"></i>
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= BASE_URL ?>assets/js/main.js"></script>
</body>
</html>
