<?php
if (session_status() === PHP_SESSION_NONE) session_start();
if (!defined('BASE_URL')) require_once __DIR__ . '/config.php';
?>
<nav class="navbar navbar-expand-lg navbar-ruma fixed-top">
    <div class="container">
        <a class="navbar-brand" href="<?= BASE_URL ?>index.php">
            <img src="<?= BASE_URL ?>assets/images/logo.jpg" alt="Ruma Planner">
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMain">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navMain">
            <ul class="navbar-nav ms-auto align-items-lg-center gap-1">
                <li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>index.php">Beranda</a></li>
                <li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>paket.php">Paket</a></li>
                <li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>vendor.php">Vendor</a></li>
                <li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>index.php#tentang">Tentang</a></li>
                <li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>kontak.php">Kontak</a></li>
                <?php if (isset($_SESSION['user_id'])): ?>
                    <?php if ($_SESSION['role'] === 'admin'): ?>
                        <li class="nav-item ms-2">
                            <a class="btn btn-gold btn-sm px-4" href="<?= BASE_URL ?>admin/dashboard.php">Dashboard Admin</a>
                        </li>
                    <?php else: ?>
                        <li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>client/riwayat.php">Pesanan Saya</a></li>
                        <li class="nav-item dropdown ms-2">
                            <a class="nav-link dropdown-toggle d-flex align-items-center gap-2" href="#" data-bs-toggle="dropdown">
                                <span style="width:32px;height:32px;background:rgba(255,255,255,0.15);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:0.8rem;">
                                    <?= strtoupper(substr($_SESSION['nama'], 0, 1)) ?>
                                </span>
                                <?= htmlspecialchars($_SESSION['nama']) ?>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <li><a class="dropdown-item" href="<?= BASE_URL ?>client/profil.php"><i class="bi bi-person me-2"></i>Profil Saya</a></li>
                                <li><a class="dropdown-item" href="<?= BASE_URL ?>client/riwayat.php"><i class="bi bi-clock-history me-2"></i>Riwayat</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item text-danger" href="<?= BASE_URL ?>logout.php"><i class="bi bi-box-arrow-right me-2"></i>Logout</a></li>
                            </ul>
                        </li>
                    <?php endif; ?>
                <?php else: ?>
                    <li class="nav-item ms-2">
                        <a class="btn btn-outline-light btn-sm px-4" href="<?= BASE_URL ?>login.php">Masuk</a>
                    </li>
                    <li class="nav-item">
                        <a class="btn btn-gold btn-sm px-4" href="<?= BASE_URL ?>register.php">Daftar</a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>
