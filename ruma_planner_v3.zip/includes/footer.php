<?php if (!defined('BASE_URL')) require_once __DIR__ . '/config.php'; ?>
<footer class="footer">
    <div class="container">
        <div class="row g-5">
            <div class="col-lg-4 col-md-6">
                <div class="footer-brand">
                    <img src="<?= BASE_URL ?>assets/images/logo.jpg" alt="Ruma Planner" class="footer-logo">
                    <p>Mewujudkan pernikahan impian Anda dengan sentuhan elegan dan profesionalisme terbaik. <em><?= SITE_TAGLINE ?></em></p>
                    <div class="mt-3 d-flex gap-3">
                        <a href="#" style="color:var(--gold);font-size:1.2rem;"><i class="bi bi-instagram"></i></a>
                        <a href="#" style="color:var(--gold);font-size:1.2rem;"><i class="bi bi-facebook"></i></a>
                        <a href="#" style="color:var(--gold);font-size:1.2rem;"><i class="bi bi-whatsapp"></i></a>
                    </div>
                </div>
            </div>
            <div class="col-lg-2 col-md-3 col-6">
                <h5>Navigasi</h5>
                <ul class="footer-links">
                    <li><a href="<?= BASE_URL ?>index.php">Beranda</a></li>
                    <li><a href="<?= BASE_URL ?>paket.php">Paket Wedding</a></li>
                    <li><a href="<?= BASE_URL ?>vendor.php">Direktori Vendor</a></li>
                    <li><a href="<?= BASE_URL ?>index.php#tentang">Tentang Kami</a></li>
                    <li><a href="<?= BASE_URL ?>kontak.php">Kontak</a></li>
                </ul>
            </div>
            <div class="col-lg-2 col-md-3 col-6">
                <h5>Akun</h5>
                <ul class="footer-links">
                    <li><a href="<?= BASE_URL ?>login.php">Masuk</a></li>
                    <li><a href="<?= BASE_URL ?>register.php">Daftar</a></li>
                    <?php if (isset($_SESSION['user_id'])): ?>
                    <li><a href="<?= BASE_URL ?>client/riwayat.php">Pesanan Saya</a></li>
                    <li><a href="<?= BASE_URL ?>logout.php">Logout</a></li>
                    <?php endif; ?>
                </ul>
            </div>
            <div class="col-lg-4 col-md-6">
                <h5>Hubungi Kami</h5>
                <div class="footer-contact-item">
                    <i class="bi bi-geo-alt-fill"></i>
                    <span><?= ADDRESS ?></span>
                </div>
                <div class="footer-contact-item">
                    <i class="bi bi-telephone-fill"></i>
                    <a href="tel:<?= PHONE ?>" style="color:inherit;text-decoration:none;"><?= PHONE ?></a>
                </div>
                <div class="footer-contact-item">
                    <i class="bi bi-envelope-fill"></i>
                    <a href="mailto:<?= EMAIL_SITE ?>" style="color:inherit;text-decoration:none;"><?= EMAIL_SITE ?></a>
                </div>
                <div class="footer-contact-item">
                    <i class="bi bi-instagram"></i>
                    <span><?= INSTAGRAM ?></span>
                </div>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; <?= date('Y') ?> <strong style="color:var(--gold)">Ruma Planner</strong> — <?= SITE_TAGLINE ?>. Owner: <?= OWNER ?></p>
        </div>
    </div>
</footer>
