<?php
// =====================================================
// KONFIGURASI GLOBAL - Ruma Planner
// =====================================================

if (!defined('BASE_URL')) {
    // Deteksi otomatis BASE_URL
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost:8080';
    
    // Cari path folder project ini
    $docRoot = rtrim(str_replace('\\','/', $_SERVER['DOCUMENT_ROOT'] ?? ''), '/');
    $scriptPath = str_replace('\\','/', __DIR__);
    // __DIR__ = .../ruma_planner_final/includes  -> go up 1 = project root
    $projectRoot = dirname($scriptPath);
    
    if ($docRoot && strpos($projectRoot, $docRoot) === 0) {
        $baseDir = substr($projectRoot, strlen($docRoot));
    } else {
        // fallback: derive from SCRIPT_NAME
        $script = str_replace('\\','/', $_SERVER['SCRIPT_NAME'] ?? '/index.php');
        // Remove filename, keep dirs up to project root
        // If called from includes/ subfolder, go up accordingly
        $parts = explode('/', trim($script, '/'));
        // find index.php or similar at root level  
        // just use the top-level folder of the script
        if (count($parts) >= 2) {
            $baseDir = '/' . $parts[0];
        } else {
            $baseDir = '';
        }
    }
    
    define('BASE_URL', $protocol . '://' . $host . $baseDir . '/');
}

define('SITE_NAME',    'Ruma Planner');
define('SITE_TAGLINE', 'From Dream, to a Moment');
define('OWNER',        'Riski Nang Bayu');

define('UPLOAD_PAKET',    __DIR__ . '/../assets/uploads/paket/');
define('UPLOAD_BAYAR',    __DIR__ . '/../assets/uploads/pembayaran/');
define('UPLOAD_URL_PAKET', BASE_URL . 'assets/uploads/paket/');
define('UPLOAD_URL_BAYAR', BASE_URL . 'assets/uploads/pembayaran/');

define('ALLOWED_IMG',   ['image/jpeg','image/png','image/jpg','image/webp']);
define('MAX_FILE_SIZE', 5 * 1024 * 1024);

define('PHONE',     '+62 812-3456-7890');
define('EMAIL_SITE','info@rumaplanner.com');
define('ADDRESS',   'Padangsidimpuan, Sumatera Utara');
define('INSTAGRAM', '@rumaplanner');
