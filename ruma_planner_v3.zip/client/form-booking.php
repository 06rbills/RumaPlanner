<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/koneksi.php';
require_once __DIR__ . '/../includes/session.php';
requireClient();

$paket_id = (int)($_GET['paket'] ?? 0);
if (!$paket_id) { header('Location: ' . BASE_URL . 'paket.php'); exit(); }

$stmt = $pdo->prepare("SELECT * FROM paket WHERE id=? AND is_active=1");
$stmt->execute([$paket_id]);
$paket = $stmt->fetch();
if (!$paket) { header('Location: ' . BASE_URL . 'paket.php'); exit(); }

$error = '';

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    requireCsrf();
    $mempelai_pria   = sanitize($pdo, $_POST['nama_mempelai_pria'] ?? '');
    $mempelai_wanita = sanitize($pdo, $_POST['nama_mempelai_wanita'] ?? '');
    $tgl_acara       = sanitize($pdo, $_POST['tanggal_acara'] ?? '');
    $lokasi          = sanitize($pdo, $_POST['lokasi'] ?? '');
    $jml_tamu        = (int)($_POST['jumlah_tamu'] ?? 0);
    $catatan         = sanitize($pdo, $_POST['catatan'] ?? '');

    if (empty($mempelai_pria) || empty($mempelai_wanita) || empty($tgl_acara) || empty($lokasi) || $jml_tamu < 1) {
        $error = 'Semua field wajib diisi.';
    } elseif (strtotime($tgl_acara) <= time()) {
        $error = 'Tanggal acara harus di masa depan.';
    } elseif ($jml_tamu > $paket['max_tamu']) {
        $error = 'Jumlah tamu melebihi kapasitas paket (' . $paket['max_tamu'] . ' tamu).';
    } else {
        $kode   = generateKodeBooking();
        $total  = $paket['harga'];
        $dp     = $total * 0.3;
        $user_id = $_SESSION['user_id'];

        $stmt = $pdo->prepare("INSERT INTO booking (kode_booking,id_user,id_paket,nama_mempelai_pria,nama_mempelai_wanita,tanggal_acara,lokasi,jumlah_tamu,catatan,total_harga,dp_amount,status) VALUES (?,?,?,?,?,?,?,?,?,?,?,'Pending')");
        if ($stmt->execute([$kode, $user_id, $paket_id, $mempelai_pria, $mempelai_wanita, $tgl_acara, $lokasi, $jml_tamu, $catatan, $total, $dp])) {
            $booking_id = $pdo->lastInsertId();
            setFlash('success', 'Booking berhasil! Silakan upload bukti pembayaran DP.');
            header('Location: ' . BASE_URL . 'client/upload-bayar.php?id=' . $booking_id);
            exit();
        } else {
            $error = 'Gagal membuat booking. Silakan coba lagi.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Booking — <?= SITE_NAME ?></title>
    <link rel="shortcut icon" href="<?= BASE_URL ?>assets/images/icon.jpg">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
</head>
<body>
<?php include '../includes/navbar.php'; ?>

<div class="page-header" style="padding-top:100px;">
    <div class="container">
        <h1>Form Pemesanan</h1>
        <p style="color:rgba(255,255,255,0.75);">Isi data acara pernikahan Anda</p>
    </div>
</div>

<section class="section-padding">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <?php if ($error): ?>
                <div class="alert alert-danger mb-4">
                    <i class="bi bi-exclamation-circle me-2"></i><?= $error ?>
                </div>
                <?php endif; ?>

                <!-- Paket Summary -->
                <div class="p-4 rounded-xl mb-4" style="background:linear-gradient(135deg,var(--maroon-dark),var(--maroon));color:white;">
                    <div class="row align-items-center">
                        <div class="col">
                            <div style="font-size:0.78rem;opacity:0.7;text-transform:uppercase;letter-spacing:0.5px;">Paket yang Dipesan</div>
                            <h4 style="font-family:var(--font-display);margin:4px 0;"><?= htmlspecialchars($paket['nama_paket']) ?></h4>
                            <span style="background:rgba(255,255,255,0.2);padding:3px 12px;border-radius:50px;font-size:0.78rem;"><?= $paket['kategori'] ?></span>
                        </div>
                        <div class="col-auto text-end">
                            <div style="font-size:0.78rem;opacity:0.7;">Total Harga</div>
                            <div style="font-family:var(--font-display);font-size:1.6rem;font-weight:700;color:var(--gold);">
                                <?= formatRupiah($paket['harga']) ?>
                            </div>
                            <div style="font-size:0.82rem;opacity:0.8;">DP 30%: <?= formatRupiah($paket['harga'] * 0.3) ?></div>
                        </div>
                    </div>
                </div>

                <div class="form-card">
                    <h4 style="font-family:var(--font-display);color:var(--maroon);margin-bottom:24px;">
                        <i class="bi bi-heart-fill me-2 text-gold"></i>Data Acara Pernikahan
                    </h4>
                    <form method="POST" class="needs-validation" novalidate>
                        <?= csrfField() ?>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">Nama Mempelai Pria <span class="text-danger">*</span></label>
                                <input type="text" name="nama_mempelai_pria" class="form-control" 
                                       placeholder="Nama lengkap mempelai pria"
                                       value="<?= htmlspecialchars($_POST['nama_mempelai_pria'] ?? '') ?>" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Nama Mempelai Wanita <span class="text-danger">*</span></label>
                                <input type="text" name="nama_mempelai_wanita" class="form-control" 
                                       placeholder="Nama lengkap mempelai wanita"
                                       value="<?= htmlspecialchars($_POST['nama_mempelai_wanita'] ?? '') ?>" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Tanggal Acara <span class="text-danger">*</span></label>
                                <input type="date" name="tanggal_acara" class="form-control" 
                                       min="<?= date('Y-m-d', strtotime('+7 days')) ?>"
                                       value="<?= htmlspecialchars($_POST['tanggal_acara'] ?? '') ?>" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Jumlah Tamu <span class="text-danger">*</span></label>
                                <input type="number" name="jumlah_tamu" class="form-control" 
                                       placeholder="Estimasi jumlah tamu" min="1" max="<?= $paket['max_tamu'] ?>"
                                       value="<?= htmlspecialchars($_POST['jumlah_tamu'] ?? '') ?>" required>
                                <div class="form-text">Maksimal <?= $paket['max_tamu'] ?> tamu untuk paket ini</div>
                            </div>
                            <div class="col-12">
                                <label class="form-label">Lokasi Acara <span class="text-danger">*</span></label>
                                <textarea name="lokasi" class="form-control" rows="3" 
                                          placeholder="Alamat lengkap lokasi acara..." required><?= htmlspecialchars($_POST['lokasi'] ?? '') ?></textarea>
                            </div>
                            <div class="col-12">
                                <label class="form-label">Catatan Tambahan</label>
                                <textarea name="catatan" class="form-control" rows="3" 
                                          placeholder="Permintaan khusus, tema, atau catatan lainnya..."><?= htmlspecialchars($_POST['catatan'] ?? '') ?></textarea>
                            </div>

                            <div class="col-12">
                                <div class="p-3 rounded-xl" style="background:var(--maroon-pale);border:1px solid rgba(105,27,27,0.15);">
                                    <div class="d-flex gap-2 align-items-start">
                                        <i class="bi bi-info-circle-fill" style="color:var(--maroon);margin-top:2px;"></i>
                                        <div style="font-size:0.85rem;">
                                            <strong>Catatan:</strong> Setelah submit, Anda akan diminta upload bukti pembayaran DP sebesar 
                                            <strong><?= formatRupiah($paket['harga'] * 0.3) ?></strong>. 
                                            Booking akan diproses setelah verifikasi pembayaran oleh admin.
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-12 d-flex gap-3">
                                <a href="<?= BASE_URL ?>detail-paket.php?id=<?= $paket['id'] ?>" class="btn btn-outline-maroon">
                                    <i class="bi bi-arrow-left me-2"></i>Kembali
                                </a>
                                <button type="submit" class="btn btn-maroon flex-grow-1">
                                    <i class="bi bi-check-circle me-2"></i>Konfirmasi Booking
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include '../includes/footer.php'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= BASE_URL ?>assets/js/main.js"></script>
</body>
</html>
