<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/koneksi.php';
require_once __DIR__ . '/../includes/session.php';
requireClient();

$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT * FROM users WHERE id=?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

$error = ''; $success = '';

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    requireCsrf();
    $nama  = sanitize($pdo, $_POST['nama'] ?? '');
    $email = sanitize($pdo, $_POST['email'] ?? '');
    $no_hp = sanitize($pdo, $_POST['no_hp'] ?? '');
    $pw_lama = $_POST['password_lama'] ?? '';
    $pw_baru = $_POST['password_baru'] ?? '';

    if (empty($nama) || empty($email)) {
        $error = 'Nama dan email wajib diisi.';
    } else {
        // Check email uniqueness
        $check = $pdo->prepare("SELECT id FROM users WHERE email=? AND id!=?");
        $check->execute([$email, $user_id]);
        if ($check->fetch()) {
            $error = 'Email sudah digunakan oleh akun lain.';
        } else {
            if (!empty($pw_baru)) {
                if (!password_verify($pw_lama, $user['password'])) {
                    $error = 'Password lama tidak sesuai.';
                } elseif (strlen($pw_baru) < 6) {
                    $error = 'Password baru minimal 6 karakter.';
                } else {
                    $hashed = password_hash($pw_baru, PASSWORD_DEFAULT);
                    $stmt = $pdo->prepare("UPDATE users SET nama=?,email=?,no_hp=?,password=? WHERE id=?");
                    $stmt->execute([$nama, $email, $no_hp, $hashed, $user_id]);
                    $_SESSION['nama'] = $nama;
                    $success = 'Profil dan password berhasil diperbarui.';
                }
            } else {
                $stmt = $pdo->prepare("UPDATE users SET nama=?,email=?,no_hp=? WHERE id=?");
                $stmt->execute([$nama, $email, $no_hp, $user_id]);
                $_SESSION['nama'] = $nama;
                $success = 'Profil berhasil diperbarui.';
            }
            if (empty($error)) {
                $user['nama'] = $nama; $user['email'] = $email; $user['no_hp'] = $no_hp;
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil Saya — <?= SITE_NAME ?></title>
    <link rel="shortcut icon" href="<?= BASE_URL ?>assets/images/icon.jpg">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
</head>
<body>
<?php include '../includes/navbar.php'; ?>

<div class="page-header" style="padding-top:100px;">
    <div class="container"><h1>Profil Saya</h1></div>
</div>

<section class="section-padding">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-7">
                <?php if ($success): ?>
                <div class="alert alert-success alert-auto-dismiss"><i class="bi bi-check-circle me-2"></i><?= $success ?></div>
                <?php endif; ?>
                <?php if ($error): ?>
                <div class="alert alert-danger"><i class="bi bi-exclamation-circle me-2"></i><?= $error ?></div>
                <?php endif; ?>

                <!-- Avatar -->
                <div class="text-center mb-4">
                    <div class="mx-auto d-flex align-items-center justify-content-center rounded-circle mb-3"
                         style="width:80px;height:80px;background:linear-gradient(135deg,var(--maroon),var(--maroon-light));color:white;font-family:var(--font-display);font-size:2rem;font-weight:700;">
                        <?= strtoupper(substr($user['nama'], 0, 1)) ?>
                    </div>
                    <h5 style="font-family:var(--font-display);color:var(--maroon);"><?= htmlspecialchars($user['nama']) ?></h5>
                    <span class="badge" style="background:var(--maroon-pale);color:var(--maroon);">Client</span>
                </div>

                <div class="form-card">
                    <h5 style="font-family:var(--font-display);color:var(--maroon);margin-bottom:20px;">Edit Profil</h5>
                    <form method="POST" class="needs-validation" novalidate>
                        <?= csrfField() ?>
                        <div class="row g-3">
                            <div class="col-12">
                                <label class="form-label">Nama Lengkap <span class="text-danger">*</span></label>
                                <input type="text" name="nama" class="form-control" value="<?= htmlspecialchars($user['nama']) ?>" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Username</label>
                                <input type="text" class="form-control" value="<?= htmlspecialchars($user['username']) ?>" disabled>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">No. HP</label>
                                <input type="text" name="no_hp" class="form-control" value="<?= htmlspecialchars($user['no_hp']) ?>">
                            </div>
                            <div class="col-12">
                                <label class="form-label">Email <span class="text-danger">*</span></label>
                                <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($user['email']) ?>" required>
                            </div>
                            <div class="col-12"><hr><h6 style="color:var(--maroon);">Ubah Password (Opsional)</h6></div>
                            <div class="col-md-6">
                                <label class="form-label">Password Lama</label>
                                <input type="password" name="password_lama" class="form-control" placeholder="Kosongkan jika tidak diubah">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Password Baru</label>
                                <input type="password" name="password_baru" class="form-control" placeholder="Min. 6 karakter">
                            </div>
                            <div class="col-12">
                                <button type="submit" class="btn btn-maroon">
                                    <i class="bi bi-save me-2"></i>Simpan Perubahan
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include '../includes/footer.php'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= BASE_URL ?>assets/js/main.js"></script>
</body>
</html>
