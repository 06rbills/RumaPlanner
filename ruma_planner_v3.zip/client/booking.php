<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/session.php';
requireClient();
header('Location: ' . BASE_URL . 'client/riwayat.php');
exit();
?>
