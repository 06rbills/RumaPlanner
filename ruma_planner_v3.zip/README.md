# Ruma Planner — Wedding Organizer Platform
**by Riski Nang Bayu** | Versi Upgrade Multi-Vendor

---

## 🚀 Cara Menjalankan (XAMPP / PHP Built-in)

### Opsi A: PHP Built-in (Tanpa XAMPP)
```bash
cd ruma_planner_final
php -S localhost:8080 router.php
```
Buka: http://localhost:8080

### Opsi B: XAMPP
1. Copy folder `ruma_planner_final` ke `htdocs/`
2. Buka: http://localhost/ruma_planner_final

> **Database otomatis dibuat** (SQLite) — tidak perlu import .sql untuk PHP Built-in.
> Untuk MySQL/XAMPP, import `database.sql` ke phpMyAdmin, lalu edit `includes/koneksi.php`.

---

## 🔐 Akun Default
| Role   | Username | Password  |
|--------|----------|-----------|
| Admin  | admin    | admin123  |
| Client | budi     | client123 |

---

## ✅ Fitur Baru (Upgrade)

### 1. Direktori Vendor (`/vendor.php`)
- Listing semua vendor per kategori
- Filter: kategori, harga min/max, lokasi
- Sort: rating, paling dipesan, harga, nama
- Badge: Best Vendor, Trending, Most Booked
- Tombol Wishlist (❤️) per vendor
- Tombol WhatsApp langsung ke vendor

### 2. Detail Vendor + Kalender (`/vendor-detail.php`)
- Kalender booking interaktif per vendor
- Warna: 🟢 Tersedia | 🔴 Full Booked | 🟡 Pending
- Cek ketersediaan real-time saat pilih tanggal
- Review & rating customer
- Chat vendor via WhatsApp

### 3. Booking Vendor (`/vendor-booking.php`)
- Form booking vendor dengan validasi tanggal
- Anti double-booking otomatis
- Redirect ke WhatsApp setelah booking

### 4. API Endpoints (`/api/`)
- `availability.php` — cek status semua vendor per tanggal
- `wishlist.php` — toggle wishlist vendor
- `review.php` — submit review vendor

### 5. Floating WhatsApp Button
- Tersedia di semua halaman publik
- Auto-message template

### 6. Admin: Kelola Vendor (`/admin/vendor.php`)
- Lihat semua vendor & statistik
- Konfirmasi / batalkan booking vendor
- Statistik booking pending & confirmed

---

## 📁 Struktur Folder
```
ruma_planner_final/
├── index.php          ← Homepage (+ Vendor Highlight)
├── vendor.php         ← Direktori Vendor (BARU)
├── vendor-detail.php  ← Detail + Kalender (BARU)
├── vendor-booking.php ← Form Booking Vendor (BARU)
├── paket.php          ← Paket Wedding
├── api/
│   ├── availability.php
│   ├── wishlist.php
│   └── review.php
├── admin/
│   ├── dashboard.php
│   ├── vendor.php     ← Kelola Vendor (BARU)
│   └── ...
├── client/
│   └── riwayat.php    ← + Booking Vendor
├── includes/
│   ├── koneksi.php    ← SQLite + Vendor Tables
│   └── ...
└── assets/css/style.css  ← + Vendor & WA styles
```

---
